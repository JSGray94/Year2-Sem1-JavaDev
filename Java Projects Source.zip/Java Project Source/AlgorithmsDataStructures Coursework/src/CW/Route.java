/*
 * Created by: Jordan Stephano Gray
 * University: Edinburgh Napier University
 * Matric: 40087220
 * Year: 3
 * Module: Algorithms and Data Structures
 * Email: graybostephano@gmail.com
 * Project Purpose: Assign with task of implementing 
 * an algorithm to solve vehicle routing problems.
 * Algorithm Used: Clarke Wright Algorithm.
 * 
 */

package CW;

//This linked list class is for the linking of nodes (Routes).
//First element in list is 1 instead of 0.
public class Route {

	// Reference head node and tail node.
	private Node _head;
	private Node _tail;

	//Total requirements is result of adding each customers requirement on a route.
	private int _totalRequirement;
	//List count is the number of customers on a route.
	private int _listCount;

	// ----------------------------------------------------------------------------
	// ----------------------------------------------------------------------------

	// Default constructor.
	public Route() {

	}

	// -----------------------------------------------------------------------------
	// -----------------------------------------------------------------------------

	// An add method. Appends specifies Customer to end of Route.
	public void add(Customer data) {

		//Create a new node holding the customer
		Node node = new Node(data);

		//Set the node this customer node points to, to null.
		node.setNextCustomer(null);
		//Set tail to the next node
		_tail.setNextCustomer(node);
		_tail = node;

		// Initialise node when first element is null
		if (_head.getNextCustomer() == null) {

			_head.setNextCustomer(_tail);

		}

		// Add customers requirement to the total route requirement.
		_totalRequirement += data.c;

		_listCount++;// increment the number of elements variable
	}

	//inserts the specified element at the specified position in this
	// list.
	public void add(Customer data, int index)
	{
		//Create new temporary empty node.
		Node temp = new Node(data);
		//Create new node which equals the current head node.
		Node current = _head;

		//When current node is not null
		if (current != null) {
			// crawl to the requested index or the last element in the list,
			// whichever comes first
			for (int i = 1; i < index && current.getNextCustomer() != null; i++) {
				current = current.getNextCustomer();
			}
		}
		// set the new node's next-node reference to this node's next-node
		// reference
		temp.setNextCustomer(current.getNextCustomer());
		// now set this node's next-node reference to the new node
		current.setNextCustomer(temp);

		// Add customers requirement to the total route requirement.
		_totalRequirement += data.c;

		_listCount++;// increment the number of elements variable
	}// END FUNCTION add

	//returns the element at the specified position in this list.
	public Customer get(int index)
	{
		// index must be 1 or higher
		if (index <= 0)
			return null;

		Node current = _head;

		if (index == 1) {

			current = _head;
		} else {

			for (int i = 1; i < index; i++) {
				if (current.getNextCustomer() == null)
					return null;

				current = current.getNextCustomer();
			}
		}

		return current.getCustomer();
	}// END FUNCTION get

	//Removes the element at the specified position in this list.
	public boolean remove(int index)
	{
		// if the index is out of range, exit
		if (index < 1 || index > size())
			return false;

		Node current = _head;
		for (int i = 1; i < index; i++) {
			if (current.getNextCustomer() == null)
				return false;

			current = current.getNextCustomer();
		}
		current.setNextCustomer(current.getNextCustomer().getNextCustomer());

		_listCount--; // decrement the number of elements variable
		return true;
	}// END METHOD remove

	// Returns the number of elements in this list.
	public int size()
	{
		return _listCount;
	}// END METHOD size

	public String toString() {
		Node current = _head.getNextCustomer();
		String output = "";
		while (current != null) {
			output += "[" + current.getCustomer().toString() + "]";
			current = current.getNextCustomer();
		}
		return output;
	}// END METHOD toString

	// Add the customer entered to the start of the route.
	public void addToStart(Customer data) {

		Node tempNode = new Node(data);

		if (_tail == null) {
			_tail = tempNode;
		}
		tempNode.setNextCustomer(_head);
		_head = tempNode;

		// Add customers requirement to the total route requirement.
		_totalRequirement += data.c;

		_listCount++;// increment the number of elements variable

	}// END METHOD addToStart.

	// Check to see if this route contains the passe din customer object.
	public boolean contains(Customer theCust) {

		Node currentNode = _head;

		while (currentNode != null) {
			if (currentNode.getCustomer() == theCust) {
				return true;

			}
			currentNode = currentNode.nextCustomer;
		}

		return false;

	}//END METHOD contains

	// Adds one route onto another.
	// Takes in 2 route objects.
	public void merge(Route merged) {

		// Goes through all nodes in merged and appends to route operated on.
		for (int i = 1; i <= merged.size(); i++) {

			this.add(merged.get(i));
		}

	}//END METHOD merge

	// Takes in int and returns true or false.
	// Determines if the route has capacity for customer requirements.
	public boolean routeHasCapacity(int requirements) {

		boolean hasCap = false;

		// If the routes capacity - requirements >= 0
		if ((this._totalRequirement - requirements) >= 0)
			hasCap = true;

		if ((this._totalRequirement - requirements) < 0)
			hasCap = false;

		return hasCap;

	}//END METHOD routeHasCapacity

	// Getters and Setters-----------------------------------------------------------
	//-------------------------------------------------------------------------------
	public Customer getHead() {
		return _head.getCustomer();
	}

	public void setHead(Node head) {
		this._head = head;
	}

	public Customer getTail() {
		return _tail.getCustomer();
	}

	public void setTail(Node tail) {
		this._tail = tail;
	}

	public int getCapacity() {
		return _totalRequirement;
	}

	public void setCapacity(int capacity) {
		this._totalRequirement = capacity;
	}

	// CLASS Node
	private class Node {
		// reference to the next node in the chain,
		// or null if there isn't one.
		Node nextCustomer;
		// data carried by this node.
		// could be of any type you need.
		Customer currentCustomer;

		// -------------------------------------------------------------
		// -------------------------------------------------------------

		// Node constructor
		public Node(Customer data) {
			nextCustomer = null;
			currentCustomer = data;
		}

		// another Node constructor if we want to
		// specify the node to point to.
		public Node(Customer data, Node nextC) {
			nextCustomer = nextC;
			currentCustomer = data;
		}

		// --------------------------------------------------------------
		// --------------------------------------------------------------

		// Basic sets and gets
		public Customer getCustomer() {
			return currentCustomer;
		}

		public void setCustomer(Customer data) {
			currentCustomer = data;
		}

		public Node getNextCustomer() {
			return nextCustomer;
		}

		public void setNextCustomer(Node nextC) {
			nextCustomer = nextC;
		}

	}// END CLASS Node

}// END CLASS LinkedList
