//LibDem class derives from MP abstract class.

public class LibDem extends MP {
	
	//Set default behaviour.
	public LibDem() {
		this._beliefs = new DaftPublic();		//Sets libdem policy to DaftPublic.
		this._habitat = new CloudCuckooLand();	//Sets libdem habitat to CloudCuckooLand.
	}

}
