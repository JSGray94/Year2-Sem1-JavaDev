//Beliefs of the conservatives.

public class KnowsBest implements Beliefs {

	public String determinePolicy() {
		
		return "We know what's best. ";
		
	}

}
