//Beliefs of the LibDems.

public class DaftPublic implements Beliefs {

	public String determinePolicy() {
		
		return "The public are daft. ";
		
	}

}
