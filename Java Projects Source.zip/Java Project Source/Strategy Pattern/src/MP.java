//The main MP class all MP's will derive from.

public abstract class MP {

	//Linking MP to its behaviour.
	protected Beliefs _beliefs;
	protected Habitat _habitat;
	
	//Allow MP to use behaviours.
	//MP determines policy.
	public void implementPolicy() {
		this._beliefs.determinePolicy();
	}
	//Determines living conditions.
	public void mpLives() {
		this._habitat.lives();
	}
	
	//Getters and setters.
	//Beliefs
	public Beliefs getBeliefs() {
		return _beliefs;
	}
	public void setBeliefs(Beliefs _beliefs) {
		this._beliefs = _beliefs;
	}
	//Habitat
	public Habitat getHabitat() {
		return _habitat;
	}
	
	public void setHabitat(Habitat _habitat) {
		this._habitat = _habitat;
	}
	
	
} //END Class MP
