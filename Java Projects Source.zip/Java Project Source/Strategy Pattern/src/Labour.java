import javax.swing.JOptionPane;

//Labour class derives from MP abstract class.

public class Labour extends MP {
	
	//Constructor
	//Set default behaviour.
	public Labour() {
		this._beliefs = new Jobs();			//Sets labour policy to Jobs.
		this._habitat = new ModestHouses();	//Sets labour habitat to modest houses.
	}
	

}
