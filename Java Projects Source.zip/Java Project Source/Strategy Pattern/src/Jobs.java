//Beliefs of Labour.

public class Jobs implements Beliefs {

	public String determinePolicy() {
		
		return "Everyone needs a job. ";
	}

}
