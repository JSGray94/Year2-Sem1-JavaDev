//Beliefs of GreenParty.

public class Recycling implements Beliefs {

	public String determinePolicy() {
		
		return "We love recycling! ";
	}

}
