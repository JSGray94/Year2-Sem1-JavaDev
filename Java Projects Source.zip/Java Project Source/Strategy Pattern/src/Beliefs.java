//Interface that all of the MP's policies will implement.

public interface Beliefs {
	
	//Determines the policy of the party.
	public String determinePolicy();

}
