import javax.swing.*;

//Main class contains the programs entry point.
public class Main {
	//main entry point.
	public static void main(String[] args) {
		
		//Create a GUI object.
		GUI theGUI = new GUI();
		theGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 	//Terminates program when "X" pressed.
		theGUI.setSize(275, 180); 								//sets size of window.
		theGUI.setVisible(true);  
	}

}
