//Green party living arrangements.

public class Trees implements Habitat {

	public String lives() {
		
		return "Stay in trees. ";
	}

}
