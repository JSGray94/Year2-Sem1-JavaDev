//LibDems living arrangements.

public class CloudCuckooLand implements Habitat {

	public String lives() {
		
		return "Lives in Cloud Cuckoo Land. ";
		
	}

}
