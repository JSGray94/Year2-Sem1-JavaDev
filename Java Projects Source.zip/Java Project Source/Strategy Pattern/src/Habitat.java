//Interface for MP's living arrangements to implement.

public interface Habitat {
	
	//Method decides where party members live.
	public String lives();

}
