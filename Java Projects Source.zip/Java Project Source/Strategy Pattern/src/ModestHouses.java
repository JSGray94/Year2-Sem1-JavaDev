//Labours living arrangements.

public class ModestHouses implements Habitat {

	public String lives() {
		
		return "Stay in modest houses. ";
	}

}
