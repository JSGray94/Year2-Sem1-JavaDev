

//Conservative class derives from MP abstract class.
public class Conservative extends MP {
	
	//Set default behaviour.
	public Conservative() {
		this._beliefs = new KnowsBest();	//Set default policy to KnowsBest.
		this._habitat = new BigHouses();	//Set default habitat to BigHouses.
	}

}
