import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GUI extends JFrame {
	
	//Similar to text item.
		private JLabel item1;
		
		//constructor
		public GUI() {
			super("The Title Bar");			//Title bar.
			setLayout(new FlowLayout());	//Gives default layout
			
			item1 = new JLabel("This is a sentence. ");
			item1.setToolTipText("This will show when hovering. ");
			add(item1);						//Adds item to window.
		}

}
