//GreenParty class derives from MP abstract class.

public class GreenParty extends MP {
	
	//Constructor.
	//Set default behaviour.
	public GreenParty() {
		this._beliefs = new Recycling();	//Sets greenparty default policy to recycling.
		this._habitat = new Trees();		//Sets greenparty default habitat to trees.
	}

}
