//Conservatives living arrangements.

public class BigHouses implements Habitat {

	public String lives() {
		
		return "Lives in a large detached house. " ;
		
	}

	

}
