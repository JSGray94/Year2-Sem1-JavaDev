package command;

public class SoupOrder extends FoodOrder {

	public SoupOrder(Chef chef) {
		setChef(chef);
		setPriority(1);
	} 
	
	@Override
	public void cook() {
		this.chef.prepareThis("soup");

	}
	

}
