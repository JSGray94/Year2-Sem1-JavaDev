package command;

public abstract class FoodOrder implements Comparable <FoodOrder> {

	public Chef chef;
	public int priority;
	
	public abstract void cook();
	
	public int compareTo(FoodOrder o) {
		if(this.priority == o.priority) {
			return 0;
		}
		if(this.priority < o.priority) {
			return 1;
		}
		return -1;
	}
	
	public int getPriority() {
		return this.priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public Chef getChef() {
		return this.chef;
	}

	public void setChef(Chef chef) {
		this.chef = chef;
	}
	
	
	
}
