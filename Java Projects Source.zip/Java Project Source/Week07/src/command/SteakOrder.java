package command;

public class SteakOrder extends FoodOrder {

	public SteakOrder(Chef chef) {
		setChef(chef);
		setPriority(5);
		
	}
	
	@Override
	public void cook() {
		this.chef.prepareThis("steak");

	}

}
