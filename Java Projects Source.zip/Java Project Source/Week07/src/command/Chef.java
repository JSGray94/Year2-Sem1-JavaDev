package command;

public class Chef {
	
	public void prepareThis(String food) {
		System.out.println("I am preparing " +food);
	}

}
