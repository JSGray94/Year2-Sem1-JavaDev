package command;

import java.util.ArrayList;
import java.util.Collections;

public class Waitress {
	
	private ArrayList <FoodOrder> theOrders = new ArrayList <FoodOrder> ();

	public void takeOrder(FoodOrder theOrder) {
		this.theOrders.add(theOrder);
		Collections.sort(this.theOrders);
	}
	
	public void haveAFagBreak() {
		System.out.println("I am out back, by the bins, having a fag");
		
		try {
			Thread.sleep(5000);
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("I am back .. didn't wash my hands!");
	}
	
	public void popIntoKitchen() {
		for(FoodOrder order : this.theOrders) {
			order.cook();
		}
	}
}
