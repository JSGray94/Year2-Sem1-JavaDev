package gui02;

public class PiggyBankDemo {
	public static void main(String[] args) {
		
		/*
		PiggyBank pg = new PiggyBank();
		
		pg.addPenny();
		pg.addFiftyPence();
		System.out.println(pg.getBalance());
		*/
		
		PiggyBankUI pgui = new PiggyBankUI();
		pgui.displayMenu();
		
	}

}
