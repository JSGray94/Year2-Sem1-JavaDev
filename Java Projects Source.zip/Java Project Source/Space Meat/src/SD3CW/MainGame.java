/**-----------------------------------------------------------------------
 * Created by: Jordan Stephano Gray
 * Matric No: 40087220
 * University: Edinburgh Napier
 * Course: BSc Games Development
 * Year: 3
 * Module: Software Development 3
 * Email: graybostephano@gmail.com
 ----------------------------------------------------------------------*/

package SD3CW;

import java.awt.Graphics2D;

public class MainGame {

	public static void main(String[] args) {
		
	}

}
