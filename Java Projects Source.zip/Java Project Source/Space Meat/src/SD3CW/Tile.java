/*-----------------------------------------------------------------------
 * Created by: Jordan Stephano Gray
 * Matric No: 40087220
 * University: Edinburgh Napier
 * Course: BSc Games Development
 * Year: 3
 * Module: Software Development 3
 * Email: graybostephano@gmail.com
 * 
 * Class Tile:
 * Represents each tile object that makes up the grid in the game.
 ----------------------------------------------------------------------*/

package SD3CW;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.net.URL;

public class Tile {

	// Create an image object for the table.
	private Image _tile = null;
	
	//Width and height attributes
	private static int _width;
	private static int _height;
	//Position, x and y attributes.
	private int _x;
	private int _y;
	
	//----------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------

	
	//Default constructor.
	public Tile(int posX, int posY) {
		
		//Set pos x and pos y
		this._x = posX;
		this._y = posY;
		
		//Set the width and height of all tiles.
		_width = 100;
		_height = 100;
	}
	
	//----------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------

	// Returns an image object.
	// Takes in a file path.
	public Image getImage(String path) {
				
			//Create a temporary image to save URL to.
			Image tempImage = null;
			//Try loading the path for the file and catch any exceptions.
			try {
					
				URL imageURL = Tile.class.getResource(path);
				tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
							
			}catch (Exception e){
					
				System.out.println("Error occured during loading file. \n" + e.getMessage());
			}
			//Return Image
			return tempImage;
			
	}//END METHOD getImage(pathname)
	
	//Test to see if image has been loaded. If not then load.
	public void loadImage() {
		
		if(_tile == null)
			_tile = getImage("Tile.png");
		
	}//END METHOD loadImage()
	
	//Draw tiles to screen.
	public void draw(Graphics2D g) {
		
		//Load in the tile image.
		this.loadImage();
		//Draw each of the tiles.
		g.drawImage(this.getImage("Tile.png"), this.getX(), this.getY(), this.getWidth(), this.getHeight(),
				null);
		
	}//END METHOD draw(GraphicsObject)
	
	//---------------------------------------------------------------------------------------------------
	//---------------------------------------------------------------------------------------------------
	
	//Getters and setters.
	public Image getTile() {	//Tile image
		return _tile;
	}
	
	public static int getWidth() {	//Width
		return _width;
	}

	public static int getHeight() {	//Height
		return _height;
	}
	public int getX() {	//Pos x
		return _x;
	}

	public void setX(int x) {
		this._x = x;
	}

	public int getY() {	//Pos y
		return _y;
	}

	public void setY(int y) {
		this._y = y;
	}



}
