/*-----------------------------------------------------------------------
 * Created by: Jordan Stephano Gray
 * Matric No: 40087220
 * University: Edinburgh Napier
 * Course: BSc Games Development
 * Year: 3
 * Module: Software Development 3
 * Email: graybostephano@gmail.com
 * 
 * Class GameScreen:
 * The purpose of this class is to display the game in action during 
 * run time in a window/applet.
 ----------------------------------------------------------------------*/

//Current package working from in the solution
package SD3CW;

//Import any required libraries/resources.
import java.applet.Applet;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.net.URL;
import java.util.ArrayList;

import SD3CW.GameScreen;

//GameScreen class
public class GameScreen extends Applet {

	// Stores grid size.
	private int _gridSize;
	// Holds width and height of screen size
	private int _width = 400;
	private int _height = 400;

	// Initialise tiles for 4x4.
	// Create tile objects.
	// FIRST ROW**
	Tile tile11 = new Tile(0, 0);
	Tile tile12 = new Tile(100, 0);
	Tile tile13 = new Tile(200, 0);
	Tile tile14 = new Tile(300, 0);
	// SECOND ROW**
	Tile tile21 = new Tile(0, 100);
	Tile tile22 = new Tile(100, 100);
	Tile tile23 = new Tile(200, 100);
	Tile tile24 = new Tile(300, 100);
	// THIRD ROW**
	Tile tile31 = new Tile(0, 200);
	Tile tile32 = new Tile(100, 200);
	Tile tile33 = new Tile(200, 200);
	Tile tile34 = new Tile(300, 200);
	// FOURTH ROW**
	Tile tile41 = new Tile(0, 300);
	Tile tile42 = new Tile(100, 300);
	Tile tile43 = new Tile(200, 300);
	Tile tile44 = new Tile(300, 300);
	// END OF TILES

	// Create player object. (set posx and posy to 10 for now.)
	Player thePlayer = new Player(200, 100);

	// Create human object
	Human theHuman = new Human(100, 0);

	// Create a deathclaw object
	DeathClaw theDeathClaw = new DeathClaw(200, 200);

	// Create space bee object.
	GiantSpaceBee gSpaceBee = new GiantSpaceBee(300, 300);

	// ----------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------

	// Default constructor
	public GameScreen() {
		
		

	}

	// ----------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------

	// Draw the grid of tiles.
	public void drawGrid(Graphics2D g2, int gridSize) {

		if (gridSize == 4) {
			// Draw the new images
			// Draw the grid.
			tile11.draw(g2);
			tile12.draw(g2);
			tile13.draw(g2);
			tile14.draw(g2);

			tile21.draw(g2);
			tile22.draw(g2);
			tile23.draw(g2);
			tile24.draw(g2);

			tile31.draw(g2);
			tile32.draw(g2);
			tile33.draw(g2);
			tile34.draw(g2);

			tile41.draw(g2);
			tile42.draw(g2);
			tile43.draw(g2);
			tile44.draw(g2);
		} // END of drawing 4x4 tile grid.
	}

	// Main entry point of applet.
	public void paint(Graphics g) {

		// Set the size of the window.
		this.setSize(this.getWidth(), this.getHeight());

		// Cast the passed in Graphics object to a Graphics2D object and set it
		Graphics2D g2 = (Graphics2D) g;

		// Draws the grid.
		drawGrid(g2, 4);

		// Draw the player to screen. thePlayer.draw(g2);
		thePlayer.loadImage();
		// Draw player.
		g2.drawImage(thePlayer.getImage("Player.png"), thePlayer.getX() + 10, thePlayer.getY() + 10,
				thePlayer.getWidth(), thePlayer.getHeight(), this);
				// thePlayer.draw(g2);
		

		// Draw human to the screen
		theHuman.loadImage();
		theHuman.draw(g2);

		// Draw Deathclaw
		theDeathClaw.loadImage();
		theDeathClaw.draw(g2);

		// Draw giant space bee.
		gSpaceBee.loadImage();
		g2.drawImage(gSpaceBee.getImage("SpaceBee.png"), gSpaceBee.getX() + 10, gSpaceBee.getY() + 10,
				gSpaceBee.getWidth(), gSpaceBee.getHeight(), this);
				// gSpaceBee.draw(g2);

		//repaint();

	}

	// -----------------------------------------------------------------------------------------------------------------
	// -----------------------------------------------------------------------------------------------------------------

	// Getters and setters.
	public int getGridSize() {
		return _gridSize;
	}

	public void setGridSize(int gridSize) {
		this._gridSize = gridSize;
	}

	public int getWidth() {
		return _width;
	}

	public void setWidth(int width) {
		this._width = width;
	}

	public int getHeight() {
		return _height;
	}

	public void setHeight(int height) {
		this._height = height;
	}

}
