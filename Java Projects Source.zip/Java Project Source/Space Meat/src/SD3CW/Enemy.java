/*-----------------------------------------------------------------------
 * Created by: Jordan Stephano Gray
 * Matric No: 40087220
 * University: Edinburgh Napier
 * Course: BSc Games Development
 * Year: 3
 * Module: Software Development 3
 * Email: graybostephano@gmail.com
 * 
 * Class Enemy:
 * A base class for all enemy entities, will hold enemy info and methods
 * to be inherited from by subclasses of enemies.
 ----------------------------------------------------------------------*/

package SD3CW;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;

public class Enemy {

	// Some class attributes.
	private int _width; // The width of the enemy character
	private int _height; // The height of the enemy character

	private int _x; // Position of enemy x on the grid.
	private int _y; // Position of enemy x on the grid.

	private boolean _alive; // Determines whether the enemy is alive of dead.

	private Image _enemy = null; // Image attribute. Set to null.
	
	private String _enemyType = null;	//Defines type of enemy as a string

	// ------------------------------------------------------------------------------------
	// ------------------------------------------------------------------------------------

	// Default constructor, runs when an enemy object is instantiated.
	public Enemy(int positionX, int positionY) {

		this._width = 80;
		this._height = 80;
		this._alive = true;
		this._x = positionX;
		this._y = positionY;

	}

	// -------------------------------------------------------------------------------------
	// -------------------------------------------------------------------------------------

	/*
	// A method that returns a specific enemy based on name input.
	//Part of the factory pattern.
	public Enemy createEnemy(String enemyType) {
		
		//Instantiate an enemy object.
		Enemy theEnemy = null;
		
		//Test if statements for each of 3 possible enemies.
		if(_enemyType.equalsIgnoreCase("human")) {
			
			//Sets returned object to a human object.
			theEnemy = new Human(_x, _y);
		}
		else if(_enemyType.equalsIgnoreCase("deathclaw")) {
			
			//Sets returned enemy object to a deathclaw object.
			theEnemy = new DeathClaw(_x, _y);
		}
		else if(_enemyType.equalsIgnoreCase("spacebee")) {
			
			//Sets returned enemy object to a space bee object.
			theEnemy = new GiantSpaceBee(_x, _y);
		}
		
		return theEnemy;

	}//END METHOD createEnemy.
	*/
	
	//A method used to spawn enemy
	public void spawn() {
		
		
	}

	// A method that moves the enemy.
	public void move() {

	}

	// A method that removes enemy object when dead.
	public void remove() {

	}

	// Returns an image object.
	// Takes in a file path.
	public Image getImage(String path) {

		// Create a temporary image to save URL to.
		Image tempImage = null;
		// Try loading the path for the file and catch any exceptions.
		try {

			URL imageURL = Enemy.class.getResource(path);
			tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);

		} catch (Exception e) {

			System.out.println("Error occured during loading file. \n" + e.getMessage());
		}
		// Return Image
		return tempImage;

	}// END METHOD getImage(pathname)

	// Test to see if image has been loaded. If not then load.
	public void loadImage() {

		if (_enemy == null)
			_enemy = getImage("");

	}// END METHOD loadImage()

	// Draw tiles to screen.
	public void draw(Graphics2D g) {

		// Load in the tile image.
		this.loadImage();
		// Draw each of the tiles.
		g.drawImage(this.getImage(""), this.getX(), this.getY(), this.getWidth(), this.getHeight(), null);

	}// END METHOD draw(GraphicsObject)

	// -------------------------------------------------------------------------------------
	// -------------------------------------------------------------------------------------

	public int getX() {
		return _x;
	}

	public void setX(int x) {
		this._x = x;
	}

	public int getY() {
		return _y;
	}

	public void setY(int y) {
		this._y = y;
	}

	public boolean isAlive() {
		return _alive;
	}

	public void setAlive(boolean alive) {
		this._alive = alive;
	}

	public int getWidth() {
		return _width;
	}

	public int getHeight() {
		return _height;
	}
	
	public String getEnemyType() {
		return _enemyType;
	}

	public void setEnemyType(String enemyType) {
		this._enemyType = enemyType;
	}

}// END CLASS Enemy
