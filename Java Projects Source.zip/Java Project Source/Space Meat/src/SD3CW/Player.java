/*-----------------------------------------------------------------------
 * Created by: Jordan Stephano Gray
 * Matric No: 40087220
 * University: Edinburgh Napier
 * Course: BSc Games Development
 * Year: 3
 * Module: Software Development 3
 * Email: graybostephano@gmail.com
 * 
 * Class Player:
 * Holds information and methods for the player object. This will
 * include positions, width, height etc and also methods may include
 * spawn(), move() etc.
 ----------------------------------------------------------------------*/

package SD3CW;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.net.URL;

public class Player {

	// Some class attributes.
	private int _width; // The width of the player character
	private int _height; // The height of the player character
	private int _x; // The position of the player character on the tiles
	private int _y;

	// Create an image object for the player.
	private Image _player = null;

	private boolean _alive; // Holds whether the player is alive or dead
	// Determines what the players diet consists of.
	private boolean _dietRodent;
	private boolean _dietSpaceDog;
	private boolean _dietEnemy;

	//----------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------
	
	// Default constructor.
	public Player(int posX, int posY) {

		// Set pos x and pos y
		this._x = posX;
		this._y = posY;

		// Set the width and height of the player.
		_width = 80;
		_height = 80;
	}

	//-----------------------------------------------------------------------------------------
	//-----------------------------------------------------------------------------------------
	
	// A method that spawns an player.
	public void spawn() {

	}

	// A method that moves the player.
	public void move() {

	}
	
	public void moveLeft() {
		
		
	}

	// A method that removes player object when dead.
	public void remove() {

	}

	// Returns an image object.
	// Takes in a file path.
	public Image getImage(String path) {

		// Create a temporary image to save URL to.
		Image tempImage = null;
		// Try loading the path for the file and catch any exceptions.
		try {

			URL imageURL = Player.class.getResource(path);
			tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);

		} catch (Exception e) {

			System.out.println("Error occured during loading file. \n" + e.getMessage());
		}
		// Return Image
		return tempImage;

	}//END METHOD getImage(pathname)

	// Test to see if image has been loaded. If not then load.
	public void loadImage() {

		if (_player == null)
			_player = getImage("Player.png");

	}//END METHOD loadImage()

	// Draw player to screen.
	public void draw(Graphics2D g) {

		// Load in the player image.
		this.loadImage();
		// Draw the player
		g.drawImage(this.getImage("Player.png"), this.getX() + 10, this.getY() + 10, this.getWidth(),
				this.getHeight(), null);

	}//END METHOD draw(GraphicsObject)

	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------

	// Getters and setters.
	public Image getPlayer() { // Player image
		return _player;
	}

	public int getWidth() { // Width
		return _width;
	}
	public int getHeight() { // Height
		return _height;
	}

	public int getX() { // Pos x
		return _x;
	}
	public void setX(int x) {
		this._x = x;
	}
	public int getY() { // Pos y
		return _y;
	}
	public void setY(int y) {
		this._y = y;
	}

}// END OF PLAYER CLASS
