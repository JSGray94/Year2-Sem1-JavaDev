/*-----------------------------------------------------------------------
 * Created by: Jordan Stephano Gray
 * Matric No: 40087220
 * University: Edinburgh Napier
 * Course: BSc Games Development
 * Year: 3
 * Module: Software Development 3
 * Email: graybostephano@gmail.com
 * 
 * Class Human:
 * Holds attributes and functions inherited from the Enemy class.
 * Should spawn a human entity when necessary and do all the necessary
 * functions. Acts as an enemy to the player.
 ----------------------------------------------------------------------*/

package SD3CW;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;

public class Human extends Enemy {

	// Image variable.
	private Image _human = null; // Image attribute. Set to null.

	// ------------------------------------------------------------------------
	// ------------------------------------------------------------------------

	public Human(int positionX, int positionY) {
		super(positionX, positionY);

	}

	// ------------------------------------------------------------------------
	// ------------------------------------------------------------------------

	// Returns an image object.
	// Takes in a file path.
	public Image getImage(String path) {

		// Create a temporary image to save URL to.
		Image tempImage = null;
		// Try loading the path for the file and catch any exceptions.
		try {

			URL imageURL = Human.class.getResource(path);
			tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);

		} catch (Exception e) {

			System.out.println("Error occured during loading file. \n" + e.getMessage());
		}
		// Return Image
		return tempImage;

	}// END METHOD getImage(pathname)

	// Test to see if image has been loaded. If not then load.
	public void loadImage() {

		if (_human == null)
			_human = getImage("Human.png");

	}// END METHOD loadImage()

	// Draw Human to screen.
	public void draw(Graphics2D g) {

		// Load in the enemy image.
		this.loadImage();
		// Draw each of enemy tiles.
		g.drawImage(this.getImage("Human.png"), this.getX() + 10, this.getY() + 10, 
				this.getWidth(), this.getHeight(), null);

	}// END METHOD draw(GraphicsObject)
	
	public void moveLeft() {
		
		this.setX(getX() - 100);
		
	}

	// ------------------------------------------------------------------------
	// ------------------------------------------------------------------------

}
