/*-----------------------------------------------------------------------
 * Created by: Jordan Stephano Gray
 * Matric No: 40087220
 * University: Edinburgh Napier
 * Course: BSc Games Development
 * Year: 3
 * Module: Software Development 3
 * Email: graybostephano@gmail.com
 * 
 * Class SettingsGUI:
 * This is where the user can interact with the program during runtime
 * and will give a variety of options.
 ----------------------------------------------------------------------*/

package SD3CW;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.Graphics2D;

import javax.swing.JButton;
import javax.swing.JCheckBox;

public class SettingsGUI {

	
	private JFrame frmSpaceMeatSettings;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SettingsGUI window = new SettingsGUI();
					window.frmSpaceMeatSettings.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SettingsGUI() {
		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSpaceMeatSettings = new JFrame();
		frmSpaceMeatSettings.setResizable(false);
		frmSpaceMeatSettings.setTitle("Space Meat Settings");
		frmSpaceMeatSettings.setBounds(100, 100, 412, 300);
		frmSpaceMeatSettings.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSpaceMeatSettings.getContentPane().setLayout(null);
		
		JLabel lblIntro = new JLabel("<html>Welcome to Space Meat! <br> Here you can adjust the games settings before getting started.</html>");
		lblIntro.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		lblIntro.setBounds(10, 11, 414, 36);
		frmSpaceMeatSettings.getContentPane().add(lblIntro);
		
		JComboBox gridSizeComboBox = new JComboBox();
		gridSizeComboBox.setBounds(97, 88, 106, 20);
		frmSpaceMeatSettings.getContentPane().add(gridSizeComboBox);
		
		JLabel lblGridSize = new JLabel("Grid Size:");
		lblGridSize.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		lblGridSize.setBounds(10, 91, 77, 14);
		frmSpaceMeatSettings.getContentPane().add(lblGridSize);
		
		JButton btnRevertMove = new JButton("Revert Move");
		btnRevertMove.setFont(new Font("Letter Gothic Std", Font.PLAIN, 11));
		btnRevertMove.setBounds(258, 122, 117, 23);
		frmSpaceMeatSettings.getContentPane().add(btnRevertMove);
		
		JButton btnMove = new JButton("Move");
		btnMove.setFont(new Font("Letter Gothic Std", Font.PLAIN, 11));
		btnMove.setBounds(258, 87, 117, 22);
		frmSpaceMeatSettings.getContentPane().add(btnMove);
		
		JLabel lblDiet = new JLabel("Diet:");
		lblDiet.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		lblDiet.setBounds(10, 126, 46, 14);
		frmSpaceMeatSettings.getContentPane().add(lblDiet);
		
		JCheckBox chckbxSpaceRodents = new JCheckBox("Space Rodents");
		chckbxSpaceRodents.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		chckbxSpaceRodents.setBounds(10, 147, 121, 23);
		frmSpaceMeatSettings.getContentPane().add(chckbxSpaceRodents);
		
		JCheckBox chckbxSpaceDogs = new JCheckBox("Space Dogs");
		chckbxSpaceDogs.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		chckbxSpaceDogs.setBounds(10, 173, 121, 23);
		frmSpaceMeatSettings.getContentPane().add(chckbxSpaceDogs);
		
		JCheckBox chckbxEnemies = new JCheckBox("Enemies");
		chckbxEnemies.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		chckbxEnemies.setBounds(10, 199, 121, 23);
		frmSpaceMeatSettings.getContentPane().add(chckbxEnemies);
	}
}
