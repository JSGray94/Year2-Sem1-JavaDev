/*-----------------------------------------------------------------------
 * Created by: Jordan Stephano Gray
 * Matric No: 40087220
 * University: Edinburgh Napier
 * Course: BSc Games Development
 * Year: 3
 * Module: Software Development 3
 * Email: graybostephano@gmail.com
 * 
 * Class TileGrid:
 * Represents the tile based level as a whole grid.
 ----------------------------------------------------------------------*/

package SD3CW;

import java.awt.Graphics2D;
import java.util.ArrayList;

//Tile grid class
public class TileGrid {

	// Determines the size of the grid.
	// Default size is 4x4 tiles.
	private int _size;
	
	//----------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------

	// Create a default constructor. Set size to 4x4.
	public TileGrid() {

		this._size = 4;
	}

	// Create a custom constructor.
	public TileGrid(int gridSize) {

		this._size = gridSize;
	}
	
	//----------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------

	// If the default size selected is 4
	public void setSize4x4() {

		if (this._size == 4) {

		}

	}

	// Draw tiles to screen.
	public void draw(Graphics2D g) {

		

	}
	
	//----------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------


}
