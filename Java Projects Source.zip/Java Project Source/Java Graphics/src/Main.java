import java.awt.Color;
import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JPanel;

import static java.lang.Math.*;

//Main class extends JFrame
public class Main extends JFrame {
	
	//The constructor for the Main() class
	public Main() throws HeadlessException {
		
		setSize(800, 600);				//Sets size of the pane.
		setLocationRelativeTo(null);	//Sets the location of the pane.
		setDefaultCloseOperation(EXIT_ON_CLOSE);	//Exits the pane upon closing.
		setContentPane(new DrawArea());
		setVisible(true);				//Makes the pane visible.
	}

	//Main entry point of the program
	public static void main(String[] args) {

		new Main();		//Create an instance of the Main class.
		
	}

}//END OF Main CLASS

//
class DrawArea extends JPanel {
	//Declare a point object.
	Point A = null;
	Point B = null;
	
	int nbrOfLoops = 100;	//Number of loops
	int length = 100;		//Length of curve
	
	//Constructor for draw area class.
	public DrawArea() {
		
		A = new Point(250, 250);	//Set point object A.
		B = new Point(200, 200);	//Set point object B.
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		/*
		g.drawRect(A.x, A.y, 50, 50);	//Draw rectangle/square.
		g.drawLine(A.x, A.y, B.x, B.y);	//Draw a line object between 2 points.
		//Draws a string at both points.
		g.drawString("A", A.x, A.y);
		g.drawString("B", B.x, B.y);
		*/
		
		for(int i = 0; i < 400; i++) {
			
			//Creates a filled rectangle
			//g.fillRect(0, 0, 800, 600);
			//Sets graphic g colour
			g.setColor(Color.orange);
			
			//g.drawRect(A.x + i, A.y + (int) (length * sin(nbrOfLoops PI * i / 200.0)), 1, 1);	//Draws a sin wave
			//g.drawRect(A.x + i, A.y + (int) (length * cos(nbrOfLoops * PI * i / 200.0)), 1, 1);	//Draws a cos wave

			//Interpolates lines to create a pattern
			g.drawLine(A.x + (int) (length  *cos(PI * i / 200.0)* (1 - cos(nbrOfLoops * PI * i / 200.0))),
					A.y + (int) (length *sin(PI * i / 200.0)* (1 - cos(nbrOfLoops * PI * i / 200.0))),
					A.x + (int) (length *cos(PI * (i+1) / 200.0)* (1 - cos(nbrOfLoops * PI * (i+1) / 200.0))),
					A.x + (int) (length *sin(PI * (i+1) / 200.0)* (1 - cos(nbrOfLoops * PI * (i+1) / 200.0))));	

			
		}
		
	}
	
}//END OF DrawArea CLASS