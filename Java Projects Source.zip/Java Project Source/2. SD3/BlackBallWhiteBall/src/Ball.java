import javax.swing.JOptionPane;
import java.util.Random;

//Main ball class to be inherited from.
public abstract class Ball {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Portion that randomly generates numbers.
		String output;
		int num;
		Random numGenerator = new Random();
		
		//Generates a random number between 0 and 1
		num = numGenerator.nextInt(1);
		
		//Determines when you get a white ball
		if(num == 2)
		{
			output = "You got a White Ball! ";
			
			//Display Message
			JOptionPane.showMessageDialog(null, output, "", JOptionPane.INFORMATION_MESSAGE);
		}
		
		//Determines when you get a black ball
		if(num == 1)
		{
			output = "You got a Black Ball! ";
			
			//Display Message
			JOptionPane.showMessageDialog(null, output, "", JOptionPane.INFORMATION_MESSAGE);
		}
		
				
		
	}

}


