
public class Main {

	public static void main(String[] args) {

		LukePritchard singerTheKooks = LukePritchard.getInstance();
		
		LukePritchard singerTheKooks2 = LukePritchard.getInstance();

		
	}

}
