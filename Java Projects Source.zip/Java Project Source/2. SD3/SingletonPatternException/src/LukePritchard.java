//Class Luke Pritchard
public class LukePritchard {
	
	//Makes universe object a uniqueInstance object.
	private static LukePritchard uniqueInstance;
	
	//Private Constructor, only allows for universe instanciation in this class.
	private LukePritchard() {}
	
	//Returns and instance of object but only if there already is not an instance.
	public static synchronized LukePritchard getInstance() {
		if(uniqueInstance == null) {
			uniqueInstance = new LukePritchard();
		}
		else {
			System.out.println("Sorry, there can be only 1 Luke. ");
			return null;
		}
		
		return uniqueInstance;
		
	}

}//END Class Universe
