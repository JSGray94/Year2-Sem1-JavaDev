//An interface for the fans
public interface Observer {
	
	public void updateFans(String latestUpdate);

}
