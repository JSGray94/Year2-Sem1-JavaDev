
public class Main {

	public static void main(String[] args) {
		//Create new band object (Observable).
		Band am = new Band();
		//Create some AMFans objects (Observers).
		AMFans f1 = new AMFans("Matt", am);
		AMFans f2 = new AMFans("Nick", am);
		
		am.freshNews("Touring in December!");
		
		am.removeObserver(f2);
		
		am.freshNews("Tour is cancelled...");
		
		
	}//End main entry point.

}//END Main Class
