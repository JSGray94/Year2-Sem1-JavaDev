import javax.swing.JOptionPane;

//Represents the fans Observer object.
public class AMFans implements Observer, DisplayElement{
	
	//Main parameters.
	private String _name;
	private String _bandUpdates;
	private Band _arcticMonkeys;
	
	//Constructor.
	public AMFans(String name, Band arcticMonkeys){
		setName(name);
		setFavBand(arcticMonkeys);
	}
	
	//Set name of the fan.
	private void setName(String name){
		this._name = name;
		
	}
	
	//Set the favourite band of the fans to AM.
	private void setFavBand(Band arcticMonkeys){
		this._arcticMonkeys = arcticMonkeys;
		this._arcticMonkeys.registerObserver(this);
	}
	
	//Update fans on latest news about the band.
	public void updateFans(String news){
		this._bandUpdates = news;
		display();
	}
	
	//Display latest news for the fans.
	public void display(){
		String output = "News for " + this._name + "\n";
		output = output + this._bandUpdates;
		JOptionPane.showMessageDialog(null, output, "", JOptionPane.INFORMATION_MESSAGE);
	}

}//END AMFans Class
