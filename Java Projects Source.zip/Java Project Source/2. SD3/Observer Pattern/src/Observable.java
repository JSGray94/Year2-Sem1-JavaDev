//An interface for the band.
public interface Observable {
	
	public void registerObserver(AMFans o);
	public void removeObserver(AMFans o);
	public void notifyObservers();
	
}
