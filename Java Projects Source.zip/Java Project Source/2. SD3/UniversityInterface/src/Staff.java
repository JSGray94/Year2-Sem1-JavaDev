
public class Staff implements UniversityInterface {
	
	

}
