
public class Student implements UniversityInterface {

	

}
