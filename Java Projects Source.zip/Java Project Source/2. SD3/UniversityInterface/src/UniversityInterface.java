
public interface UniversityInterface {

	public String toString();
	public void printDetails();
	
}
