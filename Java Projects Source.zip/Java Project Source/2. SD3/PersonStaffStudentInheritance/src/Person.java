import javax.swing.JOptionPane;


public abstract class Person {
	
	//Basic constructor
	public Person() {
		
	}
	
	//Basic variables
	private String _firstName;
	private String _lastName;
	private int _age;
	
	//String representation of person
	public String toString() {
			
			String output;
			output = "First Name: " + this._firstName + "\n" + "Last Name: " + this._lastName + "\n" + "Age: " + this._age + "\n\n";
			
			return output;
			
	}
	
	//Create an abstract method for print details.
	public abstract void printDetails();
		
	// get and set methods for first name
	public String getFirstName() {
			   
		return this._firstName;
			 
	}
	
	public void setFirstName(String firstName) {
			
		this._firstName = firstName;
			 
	}
	
	// get and set methods for second name
	public String getLastName() {
				   
		return this._lastName;
			 
	}
			  
	public void setLastName(String lastName) {
				
		this._lastName = lastName;
				 
	}
	
	//get and set methods for age.
	public int getAge() {
		
		return this._age;
	}
	public void setAge(int Age)
	{
		this._age = Age;
	}
	

}
