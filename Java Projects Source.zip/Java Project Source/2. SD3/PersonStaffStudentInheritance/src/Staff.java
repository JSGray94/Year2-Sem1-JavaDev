import javax.swing.JOptionPane;


public class Staff extends Person {
	
	//Basic constructor 
	public Staff()
	{
		
	}

	//Basic Variables
	private String _staffID;
	
	//String representation of staff member
	@Override
	public String toString() {
			
		String output;
		output = super.toString() + "Staff ID: " + this._staffID + "\n"; 
		return output;
			
	} //END toString
	
	//Display details
	@Override
	public void printDetails() {
			
		String output;
		output = toString();
			
		//Display the message
		JOptionPane.showMessageDialog(null, output, "Staff Details", JOptionPane.INFORMATION_MESSAGE);
			
	} //END printDetails
	
	//Setters and getters.
	//set and get for staffID.
	public String getStaffID() {
		
		return _staffID;
		
	}
	public void setStaffID(String StaffID) {
		
		this._staffID = StaffID;
		
	}

} //END Staff Class.
