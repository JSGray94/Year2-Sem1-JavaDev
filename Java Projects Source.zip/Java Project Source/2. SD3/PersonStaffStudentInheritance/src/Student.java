import javax.swing.JOptionPane;


public class Student extends Person {

	//Basic constructor
	public Student()
	{
		
	}
	
	//Basic variables
	private int _matricNo;
	private int _yearOfStudy;
	
	//String representation of student
	@Override
	public String toString() {
		
		String output;
		output = super.toString() + "Matric Number: " + this._matricNo + "\n" + "Year of Study: " + this._yearOfStudy + "\n\n";
		
		return output;
		
	} //END toString
	
	//Display details
	@Override
	public void printDetails() {
		
		String output;
		output = toString();
		
		//Display the message
		JOptionPane.showMessageDialog(null, output, "Student Details", JOptionPane.INFORMATION_MESSAGE);
		
	} //END printDetails
	
	// get and set methods for matricNumer
	  public int getMatricNumber() {
		   
		return this._matricNo;
		 
	   }
	  
	  public void setMatricNumber(int matricNumber) {
		
		this._matricNo = matricNumber;
		 
	   }
	
	  // get and set methods for yearOfStudy
	  public int getYearOfStudy() {
		
		return this._yearOfStudy;
		 
	   }
	   
	  public void setYearOfStudy(int yearOfStudy) {
		
		this._yearOfStudy = yearOfStudy;
		 
	   }
	

	
} //END Class Student
