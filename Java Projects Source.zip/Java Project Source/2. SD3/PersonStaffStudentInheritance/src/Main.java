import javax.swing.JOptionPane;


public class Main {

	public static void main(String[] args) {
		
		//Create student object.
		Student s1 = new Student();
		//Set properties.
		s1.setFirstName("Andrew");
		s1.setLastName("Fotheringham");
		s1.setAge(21);
		s1.setYearOfStudy(3);
		s1.setMatricNumber(40166648);
		//Print students details.
		s1.printDetails();
		
		//Create Staff object.
		Staff st1 = new Staff();
		//Set properties
		st1.setFirstName("Spongebob ");
		st1.setLastName("Squarepants");
		st1.setAge(30);
		st1.setStaffID("KRU5TY KR4B");
		//Print staff details
		st1.printDetails();

	}

}
