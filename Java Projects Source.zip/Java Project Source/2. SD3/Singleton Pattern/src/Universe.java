//Class Universe
public class Universe {
	
	//Makes universe object a uniqueInstance object.
	private static Universe uniqueInstance;
	
	//Private Constructor, only allows for universe instanciation in this class.
	private Universe() {}
	
	//Returns and instance of object but only if there already is not an instance.
	public static synchronized Universe getInstance() {
		if(uniqueInstance == null) {
			uniqueInstance = new Universe();
		}
		
		return uniqueInstance;
		
	}

}//END Class Universe
