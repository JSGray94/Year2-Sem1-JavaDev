
public class Main {

	public static void main(String[] args) {

		Universe myUniverse = Universe.getInstance();
		
	}

}
