
public abstract class PolicyFactory {
	
	//Policy attribute.
	private String _policy;

	//Setters and getters.
	public String get_policy() {
		return _policy;
	}
	public void set_policy(String _policy) {
		this._policy = _policy;
	}
	
	//Announce winning policy method.
	public void announceWinner(){
		
	}
	//Create the policy.
	public static PolicyFactory createPolicy(String _policy){
		
		PolicyFactory policyFactory = null;
		
		if(_policy.equalsIgnoreCase("one")){
			policyFactory = new PolicyOne();
		}
		if(_policy.equalsIgnoreCase("two")){
			policyFactory = new PolicyTwo();
		}
		if(_policy.equalsIgnoreCase("three")){
			policyFactory = new PolicyThree();
		}
		if(_policy.equalsIgnoreCase("four")){
			policyFactory = new PolicyFour();
		}
		if(_policy.equalsIgnoreCase("five")){
			policyFactory = new PolicyFive();
		}
		
		return policyFactory;
		
	}
	
	
}
