
public class PolicyThree extends PolicyFactory{

	public void announceWinner() {
		System.out.println("Policy 3 has won! ");

	}
	
}
