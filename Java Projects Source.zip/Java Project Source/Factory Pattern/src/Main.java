
public class Main {

	public void usePolicy(String _policy){
		PolicyFactory policyFactory;
		
		policyFactory = PolicyFactory.createPolicy(_policy);
		
		policyFactory.announceWinner();
	}
	
	public static void main(String[] args) {
		
		

	}

}