
public class PolicyOne extends PolicyFactory {

	public void announceWinner(){
		System.out.println("Policy 1 has won! ");
	}
	
}
