
public class PolicyFive extends PolicyFactory{
	
	public void announceWinner(){
		System.out.println("Policy 5 has won! ");

	}

}
