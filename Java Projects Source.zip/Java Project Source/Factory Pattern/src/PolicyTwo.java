
public class PolicyTwo extends PolicyFactory {

	public void announceWinner(){
		System.out.println("Policy 2 has won! ");
	}
	
}
