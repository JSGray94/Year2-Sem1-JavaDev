
public class PolicyFour extends PolicyFactory {
	
	public void announceWinner() {
		System.out.println("Policy 4 has won! ");

	}

}
