package BasicGUI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.factories.FormFactory;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Dialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField nameTextField;
	private JTextField matricTextField;
	private JTextField departmentTextField;

	/**
	 * Create the dialog.
	 */
	public Dialog() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("default:grow"),},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,}));
		{
			JLabel lblYourName = new JLabel("Your Name:");
			contentPanel.add(lblYourName, "2, 2, right, default");
		}
		{
			nameTextField = new JTextField();
			nameTextField.setEditable(false);
			contentPanel.add(nameTextField, "4, 2, fill, default");
			nameTextField.setColumns(10);
		}
		{
			JLabel lblYourMatric = new JLabel("Your Matric:");
			contentPanel.add(lblYourMatric, "2, 6, right, default");
		}
		{
			matricTextField = new JTextField();
			matricTextField.setEditable(false);
			contentPanel.add(matricTextField, "4, 6, fill, default");
			matricTextField.setColumns(10);
		}
		{
			JLabel lblYourDepartment = new JLabel("Your Department:");
			contentPanel.add(lblYourDepartment, "2, 10, right, default");
		}
		{
			departmentTextField = new JTextField();
			departmentTextField.setEditable(false);
			contentPanel.add(departmentTextField, "4, 10, fill, default");
			departmentTextField.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton backButton = new JButton("Back");
				backButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						dispose();
						
						GUI1 g = new GUI1();
						g.frmTextboxIsBroken.setVisible(true);
					}
				});
				backButton.setActionCommand("OK");
				buttonPane.add(backButton);
				getRootPane().setDefaultButton(backButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

	public void setValues(String name, String matricNo, String dept) {

		nameTextField.setText(name);
		matricTextField.setText(matricNo);
		departmentTextField.setText(dept);
		
	}

}
