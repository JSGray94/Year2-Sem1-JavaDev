package BasicGUI;

import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JPanel;

public class GUI1 {

	JFrame frmTextboxIsBroken;
	private JTextField nameTextField;
	private final Action action = new SwingAction();
	private JTextField matricTextField;
	private JTextField deptTextField;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI1 window = new GUI1();
					window.frmTextboxIsBroken.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmTextboxIsBroken = new JFrame();
		frmTextboxIsBroken.setResizable(false);
		frmTextboxIsBroken.setTitle("Textbox is broken. Yay");
		frmTextboxIsBroken.setBounds(100, 100, 450, 300);
		frmTextboxIsBroken.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmTextboxIsBroken.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter Name Here");
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 12));
		lblNewLabel.setBounds(25, 21, 120, 29);
		frmTextboxIsBroken.getContentPane().add(lblNewLabel);
		
		
		
		nameTextField = new JTextField();
		nameTextField.setBounds(155, 26, 186, 20);
		frmTextboxIsBroken.getContentPane().add(nameTextField);
		nameTextField.setColumns(10);
		
		JButton btnSubmit = new JButton("Next");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//String name = nameTextField.getText();
				//System.out.println(name);
				
				//gets all the text from each text field when button is pressed and sets them to strings.
				String name = nameTextField.getText();
				String matricNo = matricTextField.getText();
				String dept = deptTextField.getText();
				
				if(name.equals("") || matricNo.equals("") || dept.equals(""))
					//JOptionPane.showMessageDialog(GUI1.this, "You cannot do that.");
				
				//Close window, destroy current JFrame window.
				frmTextboxIsBroken.dispose();
				Dialog dia = new Dialog();
				dia.setValues(name, matricNo, dept);
				dia.setVisible(true);
			}
		});
		
		btnSubmit.setBounds(25, 135, 89, 23);
		frmTextboxIsBroken.getContentPane().add(btnSubmit);
		
		JLabel lblMatricNumber = new JLabel("Matric Number");
		lblMatricNumber.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblMatricNumber.setBounds(25, 61, 89, 14);
		frmTextboxIsBroken.getContentPane().add(lblMatricNumber);
		
		JLabel lblDepartment = new JLabel("Department");
		lblDepartment.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDepartment.setBounds(25, 89, 76, 14);
		frmTextboxIsBroken.getContentPane().add(lblDepartment);
		
		matricTextField = new JTextField();
		matricTextField.setBounds(155, 58, 186, 20);
		frmTextboxIsBroken.getContentPane().add(matricTextField);
		matricTextField.setColumns(10);
		
		deptTextField = new JTextField();
		deptTextField.setBounds(155, 87, 186, 20);
		frmTextboxIsBroken.getContentPane().add(deptTextField);
		deptTextField.setColumns(10);
		
		
		
		
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
