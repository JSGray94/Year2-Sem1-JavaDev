import java.util.ArrayList;

//Represents the observable band
public class Band implements Observable {
	
	//create a list containing all fans.
	private ArrayList <AMFans> theAMFans = new ArrayList();
	//A string containing news for the fans.
	private String _news;
	
	//Add fans to subscription service.
	public void registerObserver(AMFans fans) {
		this.theAMFans.add(fans);
	}
	
	//Remove fans from subscription service
	public void removeObserver(AMFans fans) {
		this.theAMFans.remove(fans);
	}
	
	//Notify fans of upcoming news.
	public void notifyObservers() {
		for(AMFans tempFans : this.theAMFans){
			tempFans.updateFans(_news);
		}
	}
	
	//Set latest news as the current news.
	public void freshNews(String news){
		setNews(news);
		notifyObservers();
	}
	
	//Setting news method.
	private void setNews(String news) {
		this._news = news;
	}
	

}//END ArcticMonkeys Class
