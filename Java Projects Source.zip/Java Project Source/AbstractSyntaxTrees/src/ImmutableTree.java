public class ImmutableTree {
	// Attributes.
	private ImmutableTree left;
	private ImmutableTree right;
	private String val;

	// Constructor.
	public ImmutableTree(String v, ImmutableTree l, ImmutableTree r) {
		val = v;
		left = l;
		right = r;
	}

	public ImmutableTree Left() {
		return left;
	}

	public ImmutableTree Right() {
		return right;
	}

	public String Val() {
		return val;
	}

	// Evaluate the expression.
	int eval(ImmutableTree t) {
		if (t.Val().equals("+"))
			return eval(t.Left()) + eval(t.Right());
		if (t.Val().equals("-"))
			return eval(t.Left()) - eval(t.Right());

		return Integer.parseInt(t.Val());
	}

}
