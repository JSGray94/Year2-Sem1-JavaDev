import java.util.*;

public class Main {

	public static void main(String[] args) {
		// Question 5
		// Expression 6+7 immutable tree.
		ImmutableTree t1 = new ImmutableTree("+", new ImmutableTree("6", null,
				null), new ImmutableTree("7", null, null));
		//Expression 1+2+3
		ImmutableTree t2 = new ImmutableTree("+", new ImmutableTree("1", null,
				null), new ImmutableTree("+", null, null));
		//Expression 1+2-3
		ImmutableTree t3 = new ImmutableTree("+", new ImmutableTree("6", null,
				null), new ImmutableTree("7", null, null));
		//Expression 1*2/5
		ImmutableTree t4 = new ImmutableTree("+", new ImmutableTree("6", null,
				null), new ImmutableTree("7", null, null));
		
		

	}



}
