import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import javafx.event.ActionEvent;
import javax.swing.*;

public class Tuna extends JFrame {

	private JTextField _tf1;
	private JTextField _tf2;
	private JTextField _tf3;
	private JPasswordField _passwordField;

	
	//constructor
	public Tuna() {
		super("The Title");
		setLayout(new FlowLayout());
		
		_tf1 = new JTextField(10);
		add(_tf1);
		_tf2 = new JTextField("Enter text here. ");
		add(_tf2);
		_tf3 = new JTextField("Uneditable", 20);
		_tf3.setEditable(false);
		add(_tf3);
		
		_passwordField = new JPasswordField("mypass");
		add(_passwordField);
		
		theHandler handler = new theHandler();	//Creates action listener object.
		_tf1.addActionListener(handler);
		_tf2.addActionListener(handler);
		_tf3.addActionListener(handler);
		_passwordField.addActionListener(handler);

	}
	
	private class theHandler implements ActionListener {
		
		public void actionPerformed(ActionEvent event) {
			
			String string = "";
			if(event.getSource() == _tf1)
				string = String.format("field 1: %s", event.getActionCommand());
			else if(event.getSource() == _tf2)
				string = String.format("field 2: %s", event.getActionCommand());
			else if(event.getSource() == _tf3)
				string = String.format("field 3: %s", event.getActionCommand());
			else if(event.getSource() == _passwordField)
				string = String.format("password field is: %s", event.getActionCommand());


			
		}
		
	}
	
}
