import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {

		Tuna j = new Tuna();
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Terminates program when "X" pressed.
		j.setSize(275, 180); //sets size of window.
		j.setVisible(true);  
		
	}

}
