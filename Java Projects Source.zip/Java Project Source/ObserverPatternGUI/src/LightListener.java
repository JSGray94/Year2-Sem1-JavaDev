import java.util.EventListener;

//Light listener interface
public interface LightListener extends EventListener {
	
	public void lightOn(LightEvent evt);	//Called back upon light on
	public void lightOff(LightEvent evt);	//Caalled back upon light off
}
