import java.util.EventObject;

//Light event.
public class LightEvent extends EventObject{
	
	public LightEvent(Object src) {
		super(src);
	}
}
