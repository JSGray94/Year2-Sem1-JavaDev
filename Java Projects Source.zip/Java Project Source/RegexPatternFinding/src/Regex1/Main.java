package Regex1;

//Imported libs.
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Main {

	public static void main(String[] args) {
		
		//Postcode regular expression. (REGEX)
		Pattern pattern = Pattern.compile("EH[0-9]{1,2}\\s[0-9-A-Z][A-Z]");
		Matcher matcher = pattern.matcher("EH17 7AR");
		if(matcher.find())
			System.out.println("Found");
		else
			System.out.println("Not Found");
		
		//Regular expression for number-operator-number range 0-9999
		Pattern pattern2 = Pattern.compile("^[0-9]{1,4}(\\+|\\-|\\/|\\*)[0-9]{1,4}$");
		Matcher matcher2 = pattern2.matcher("1*1");
		if(matcher2.find())
			System.out.println("Found");
		else
			System.out.println("Not Found");
		
		

	}

}
