package tilegame;

import java.awt.Graphics;
import java.util.ArrayList;

//Takes care of each entity.
public class EntityManager {
	
	private Handler handler;	//Handler object
	private Player player;	//Player object
	private ArrayList<Entity> entities;	//Holds the entities.
	
	public EntityManager(Handler handler, Player player) {
		
		this.handler = handler;
		this.player = player;
		entities = new ArrayList<Entity>();
	}
	
	public void tick() {
		//For every entity in the array list holding themDO
		for(int i = 0; i < entities.size(); i++) {
			
			Entity e = entities.get(i);
			e.tick();
		}
		//Keep player seperate.
		player.tick();
	}
	
	public void render(Graphics g) {
		
		//Render each entity in the array list.
		for(Entity e : entities) {
			
			e.render(g); 
		}
		
		player.render(g); 
	}
	
	public void addEntity(Entity e) {
		
		entities.add(e); 
	}
	
	//--------------------------------
	//--------------------------------
	
	public Handler getHandler() {
		
		return handler;
	}
	
	public Player getPlayer() {
		
		return player;
	}

}
