package tilegame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

//Main class of the game. Start, run etc...
public class Game implements Runnable{
	
	//Create private display object.
	private Display display;
	//Width, height and title variables.
	private int width, height;
	public String title;
	
	//Create new thread object.
	//Everything in this class runs separately to rest of app.
	private Thread thread;
	//Create running boolean for the game loop
	private boolean running = false;
	
	//A way to draw to the screen.
	//Buffer is a hidden screen but only holds data doesnt display
	private BufferStrategy bs;
	//Create graphics object.
	//Like a paint brush
	private Graphics g;
	
	//STATES**
	private State gameState;
	private State menuState;
	
	//INPUT**
	private KeyManager keyManager;
	
	//CAMERA**
	private GameCamera gameCamera;
	
	//HANDLER**
	private Handler handler;
	
	
	//----------------------------------------------
	//----------------------------------------------
	
	//Create default Game constructor.
	public Game(String title, int width, int height) {
		
		this.width = width;
		this.height = height;
		this.title = title;
		
		keyManager = new KeyManager();
		
	}
	
	//--------------------------------------------
	//--------------------------------------------

	//An initialise method to initialise the graphics etc.
	private void init() {
		
		//Create new display object upon being called.
		display = new Display(title, width, height);
		//Adds key listener to the display.
		display.getFrame().addKeyListener(keyManager);
		
		//Initialise assets from assets class.
		Assets.init();
		
		handler = new Handler(this);
		
		gameCamera = new GameCamera(handler, 0, 0);	//Initialise game cam at 0, 0
		
		//Set initial states up. set to game state.
		gameState = new GameState(handler);
		menuState = new MenuState(handler);
		State.setState(gameState); 
		
	}
	
	
	//Update method. Update variables.
	private void tick() {
		
		keyManager.tick();
		
		//If state does not = null
		if(State.getState() != null) {
			//Get the states tick method
			State.getState().tick();
		}
	}
	
	//render method. Draw to screen
	private void render() {
		
		//Sets buffer strategy object to the game canvas.
		bs = display.getCanvas().getBufferStrategy();
		//If canvas does not have buffer strategy.
		if(bs == null) {
			display.getCanvas().createBufferStrategy(3);	//Use 3 buffers
			return;
		}
		//Create paint brush.
		g = bs.getDrawGraphics();	//Set graphics object to buffer graphics.
		
		//Clear screen for each render.
		g.clearRect(0, 0, width, height); 
		
		//Draw here****
		
		//If the state the game is in doesnt = null
		if(State.getState() != null) {
			//Get the current states render method.
			State.getState().render(g); 
		}
		
		//End draw****
		bs.show();	//Show graphics
		
		g.dispose();	//Graphics object disposed of
	}
	
	//This is the main run method.
	public void run() {
		//Only runs once.
		init();
		
		//initialise and set frames per second to 60.
		int fps = 60;
		//Theres 1,000,000,000 nano seconds in a second
		//1 second divide by fps.
		double timePerTick = 1000000000 / fps;
		double delta = 0;	//Amount of time we have to call tick and render.
		long now;	//Current computer time
		long lastTime = System.nanoTime();	//Return current computer time. Nano secs
		long timer = 0;
		int ticks = 0;
		
		//The game loop
		while(running) {
			//Set now to current time nano secs
			now = System.nanoTime();
			//
			delta += (now - lastTime) / timePerTick;
			timer += now - lastTime;	//Adds to time since last block of code was called.
			lastTime = now;	
			
			//If delta is >= 1 tick and render.
			if(delta >= 1) {
				tick();
				render();
				
				ticks ++;	//Increments ticks.
				delta --;	//Subtract from delta.
			}
			
			//If timer is >= 1 second, print ticks and frames.
			if(timer >= 1000000000) {
				
				System.out.println("Ticks/Frames: " + ticks);
				ticks = 0;
				timer = 0;
			}
		}
		
		stop();	//Stop running.
	}
	
	//Synchronised to work with threads
	public synchronized void start() {
		
		//The the game is already running then return out of method.
		if(running)
			return;
		
		//When started set running to true
		running = true;
		
		thread = new Thread(this);	//Set new thread object to run game class(this).
		//This calls the run method.
		thread.start();
	}
	
	//Stop thread safely
	public synchronized void stop() {
		
		//If game has stopped then return.
		if(!running)
			return;
		
		running = false;
		
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	//----------------------------
	//----------------------------
	
	//Getters
	public KeyManager getKeyManager() {
			
		return keyManager;
	}
	
	public GameCamera getGameCamera() {
		
		return gameCamera;
	}
	
	public int getWidth() {
		
		return width;
	}
	
	public int getHeight() {
		
		return height;
	}
	
	
	
	
}
