package tilegame;

import java.awt.Graphics;

public abstract class State {
	
	//***** Can access these statics from anywhere. 
	
	//Create state object.
	private static State currentState = null;
	
	//Will set which state to render etc...
	public static void setState(State state) {
		
		currentState = state;
	}
	//Getter for state.
	public static State getState() {
		
		return currentState;
	}
	
	//***** end of statics.
	
	//CLASS
	protected Handler handler;
	
	//Basic state constructor. Takes in game parameter.
	public State(Handler handler) {
		
		this.handler = handler;
	}
	
	public abstract void tick();
	
	public abstract void render(Graphics g);

}
