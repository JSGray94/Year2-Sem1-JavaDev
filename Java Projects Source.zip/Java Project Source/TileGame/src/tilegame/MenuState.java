package tilegame;

import java.awt.Graphics;

public class MenuState extends State {

	//Default constructor.
	public MenuState(Handler handler) {
		super(handler);
		
	}
	
	@Override
	public void tick() {
		
	}

	@Override
	public void render(Graphics g) {
		
		g.drawImage(Assets.dirt, 80, 80, null);
	}

}
