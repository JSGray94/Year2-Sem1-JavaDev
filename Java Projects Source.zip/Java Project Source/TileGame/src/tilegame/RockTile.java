package tilegame;

import java.awt.image.BufferedImage;

//Cannot walk over this tile as it is solid.
public class RockTile extends Tile {

	public RockTile(int id) {
		super(Assets.rock, id);
	}
	
	//Make this type of tile solid/unwalkable.
	@Override
	public boolean isSolid() {
		
		return true;
	}

}
