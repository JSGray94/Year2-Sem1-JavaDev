package tilegame;

import java.awt.image.BufferedImage;

//Specific type of tile
public class GrassTile extends Tile {

	public GrassTile(int id) {
		super(Assets.grass, id);
		
		
	}

}
