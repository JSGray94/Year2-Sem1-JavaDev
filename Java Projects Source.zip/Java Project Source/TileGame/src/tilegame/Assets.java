package tilegame;

import java.awt.image.BufferedImage;

//This class' purpose is to load in assets.
public class Assets {
	
	//These represent size of each sprite in the sprite sheet.
	private static final int width = 80, height = 80;
	
	//Declare Buffered Image objects.
	public static BufferedImage desert, dirt, rock, grass, tree;
	//
	public static BufferedImage[] player_down, player_up, player_left, player_right;

	//Loads everything into the game
	public static void init() {
		
		//Load in sprite sheet.
		SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/SpriteSheet.png"));
		
		//Initialise animated sprites sheet (2 frames per walk cycle)
		player_down = new BufferedImage[2];	//Put in frames.
		player_up = new BufferedImage[2];
		player_left = new BufferedImage[2];
		player_right = new BufferedImage[2];
		//Crop sprites in sheet.
		player_down[0] = sheet.crop(0, height * 2, width, height);
		player_down[1] = sheet.crop(width, height * 2, width, height);
		player_up[0] = sheet.crop(width * 2, height * 2, width, height);
		player_up[1] = sheet.crop(0, height * 3, width, height);
		player_left[0] = sheet.crop(0, height * 4, width, height);
		player_left[1] = sheet.crop(width, height * 4, width, height);
		player_right[0] = sheet.crop(width, height * 3, width, height);
		player_right[1] = sheet.crop(width * 2, height * 3, width, height);

		
		//Set each object to their respective sprites in sheet.
		//Takes x, y, width, height.
		desert = sheet.crop(0, 0, width, height); 
		dirt = sheet.crop(width, 0, width, height);
		rock = sheet.crop(width * 2, 0, width, height); 
		grass = sheet.crop(0, height, width, height);
		tree = sheet.crop(width, height, width, height);

		
	}
	
}
