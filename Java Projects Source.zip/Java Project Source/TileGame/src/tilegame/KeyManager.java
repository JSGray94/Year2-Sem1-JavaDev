package tilegame;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

//This class handles key inputs.
public class KeyManager implements KeyListener{

	//An array of booleans called keys.
	private boolean[] keys;
	
	public boolean up, down, left, right;
	
	//Default constructor.
	public KeyManager() {
		
		keys = new boolean[256];
	}
	
	//Updates variables.
	public void tick() {
		
		//Based on if these keys are being pressed move player.
		up = keys[KeyEvent.VK_W];
		down = keys[KeyEvent.VK_S];
		left = keys[KeyEvent.VK_A];
		right = keys[KeyEvent.VK_D];
	}
	
	//This is called when key is pressed.
	@Override
	public void keyPressed(KeyEvent e) {
		
		//Whichever key is at e when pressed is set to true.
		keys[e.getKeyCode()] = true;
		
		System.out.println("Key Pressed. ");
	}

	//This is called when key is released
	@Override
	public void keyReleased(KeyEvent e) {
		
		//Whichever key is at e when released is set to false.
		keys[e.getKeyCode()] = false;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		
	}

}
