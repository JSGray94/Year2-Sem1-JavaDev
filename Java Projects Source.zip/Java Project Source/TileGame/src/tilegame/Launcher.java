package tilegame;

public class Launcher {
	
	public static void main(String args[]) {

		//create new game object
		Game game = new Game("Test Game", 640, 480);
		//Start the game
		game.start();
	}
	
}
