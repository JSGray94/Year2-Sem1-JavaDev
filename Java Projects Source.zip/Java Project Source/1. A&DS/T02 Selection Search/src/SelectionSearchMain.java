import java.util.Arrays;

public class SelectionSearchMain
{
 
    public static int[] selectionSort(int[] num)
    {
    	 int i, j, first, temp;  
         for ( i = num.length - 1; i > 0; i -- )  
         {
              first = 0;   //initialize to subscript of first element
              for(j = 1; j <= i; j ++)   //locate smallest element between positions 1 and i.
              {
                   if( num[ j ] < num[ first ] )         
                     first = j;
              }
              temp = num[ first ];   //swap smallest found with element in position i.
              num[ first ] = num[ i ];
              num[ i ] = temp; 
          }        
         return num;


    }
     
    public static void main(String[] args)
    {
         
        int[] unsorted = {10,34,2,56,7,67,88,42};
        System.out.println("Unsorted Array "+Arrays.toString(unsorted));

        int[] sorted = selectionSort(unsorted);
        System.out.println("Sorted Array "+Arrays.toString(sorted));
    }
}
