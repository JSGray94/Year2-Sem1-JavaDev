import java.util.Arrays;

public class BubbleSortMain
{
    public static void bubbleSort(int array[])
    {
    	 int j;
         boolean flag = true;   // set flag to true to begin first pass
         int temp;   //holding variable

         while ( flag )
         {
                flag= false;    //set flag to false awaiting a possible swap
                for( j=0;  j < array.length -1;  j++ )
                {
                       if ( array[ j ] > array[j+1] )   // change to > for ascending sort
                       {
                               temp = array[ j ];                //swap elements
                               array[ j ] = array[ j+1 ];
                               array[ j+1 ] = temp;
                              flag = true;              //shows a swap occurred  
                      } 
                } 
          } 

    }
  
    public static void main(String[] args)
    {
        int[] data = { 4, 37, 9, 6, 23, 55, 34, 0, 1 };
        System.out.println("Unsorted Array "+Arrays.toString(data));
        bubbleSort(data);
        System.out.println("Sorted Array "+Arrays.toString(data));
    }
}