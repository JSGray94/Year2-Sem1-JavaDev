
public class BinarySearchMain
{
 
    public int binarySearch(int[] data, int key)
    {
    	 int lo = 0;
         int hi = data.length - 1;
         while (lo <= hi) {
             // Key is in a[lo..hi] or not present.
             int mid = lo + (hi - lo) / 2;
             if      (key < data[mid]) 
            	 hi = mid - 1;
             else if (key > data[mid]) 
            	 lo = mid + 1;
             else return mid;
         }
         return -1;

    }
  
    public static void main(String[] args)
    {
         
        BinarySearchMain bs = new BinarySearchMain();
        int[] data = {12, 34, 65, 18, 3, 122, 54, 76};
        int key = 122;
        int result = bs.binarySearch(data, key);

        if (result == -1)
            System.out.println("Key not found in array");
        else
            System.out.println("Key "+key+" found at index: "+result);
    }
}
