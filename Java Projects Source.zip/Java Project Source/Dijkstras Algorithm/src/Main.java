import java.util.HashMap;
import java.util.LinkedList;


public class Main {

	//Returns a postfix string and takes infix String arg.
	public static String postfix(String infix) {
		
		StringBuilder output = new StringBuilder();		//Creates a StringBuilder object called output.
		LinkedList<String> stack = new LinkedList<>();	//Creates the stack comprised of only Strings.
		//For loop for each token, split up by a space.
		for(String token : infix.split("\\s")) {
			//Operator
			if(ops.containsKey(token)) {
				while(!stack.isEmpty() && isHigherPrec(token, stack.peek()))
					output.append(stack.pop()).append(' ');
				stack.push(token);
			}
			//Left parenthesis
			else if(token.equals("(")) {
				stack.push(token);
			}
			//Right parenthesis.
			else if(token.equals(")")) {
				while(!stack.peek().equals("("))
					output.append(stack.pop()).append(' ');
				stack.pop();
			
			}
			//Digit
			else {
				output.append(token).append(' ');
			}
		}
		
		while(!stack.isEmpty())
			output.append(stack.pop()).append(' ');
		
		return output.toString();
		
	}
	
	//A method that evaluates RPN using a stack machine.
	public static int evaluateRPN(String rpn) {
		
		LinkedList<String> stackMachine = new LinkedList<>();	//This is the stack that holds the input values.
		
		int returnValue = 0;	//The final return value.
		String operators = "+-*/";	//String containing usable operators.
		
		//For loop for each token in the input string split by space ' '.
		for(String t : rpn.split("\\s")) {
			//If it isn't an operator.
			if(!operators.contains(t)) {
				//Push token onto the stack.
				stackMachine.push(t);
			}
			else {
				
				int a = Integer.valueOf(stackMachine.pop());
				int b = Integer.valueOf(stackMachine.pop());
				int index = operators.indexOf(t);
				switch(index) {
				case 0:
					stackMachine.push(String.valueOf(a+b));
					break;
				case 1:
					stackMachine.push(String.valueOf(b-a));
					break;
				case 2:
					stackMachine.push(String.valueOf(a*b));
					break;
				case 3:
					stackMachine.push(String.valueOf(b/a));
					break;
				
				}
			}
		
		}
		
		returnValue = Integer.valueOf(stackMachine.pop());
		
		return returnValue;
		
	}
	
	
	//An enumerator which assigns precedence to each operator.
	private enum Operator {
		
		ADD(1), SUBTRACT(2), MULTIPLY(3), DIVIDE(4);
		final int precedence;
		Operator(int p) { precedence = p; }
	}
	//A hashmap called ops responsible for identifying operators
	//Hashmap = "String, Operator" e.g: "< *, 3>".
	private static HashMap<String, Operator> ops = new HashMap<String, Operator>() {{
		
		put("+", Operator.ADD);
		put("-", Operator.SUBTRACT);
		put("*", Operator.MULTIPLY);
		put("/", Operator.DIVIDE);
	}};

	private static boolean isHigherPrec(String op, String sub) {
		return (ops.containsKey(sub) && ops.get(sub).precedence >= ops.get(op).precedence);
	}

	public static void main(String[] args) {
		
		//Create a GUI for the user to interact with.
		//GUI gui = new GUI();
		//gui.frmInfixToRpn.setVisible(true);
		
		String myString = "7 + 8 * 3 / 5";		//Create a string containing a calculation.
		System.out.println("Infix Notation: " + myString);
		
		//Compute and display reverse polish
		String answer = postfix(myString);		//Find the RPN of the previous infix string and assign to a new string.
		System.out.println("Reverse Polish: " + answer);	//Print out the RPN.
				
		//Evaluate the RPN.
		int finalVal = evaluateRPN(answer);
		System.out.println("RPN Evaluated = " + finalVal);
	 
	
		
		
		
	}

}
