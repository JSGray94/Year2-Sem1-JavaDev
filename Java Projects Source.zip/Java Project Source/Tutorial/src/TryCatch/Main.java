package TryCatch;

/*
 * Using try and catch.
 */

public class Main {

	// Code executed here.
	public static void main(String[] args) {
		
		try {
		//Cannot divide by 2.
		int x = 0;
		int y = 2;
		int answer = y / x;
		//Gives null pointer exception.
		Object obj =null;
		obj.hashCode();
		
		//Print answer.
		System.out.println(answer);
		}//Catch arithmetic exception
		catch (ArithmeticException e) {
			
			String errorMessage = e.getMessage();
			if(errorMessage.equals("/ by zero")) {
				
				System.out.println("Error: You cannot divide by zero. ");
			}
			else {
				
				System.out.println("Math error. ");
			}
			
		}
		catch(NullPointerException npe) {
			
			System.out.println(npe.getMessage());
		}
		
		
	}

}
