package AreaTriangle;

import java.util.Scanner;

public class TriangleArea {
	
	//Creates a new scanner sc.
	//Reads the input.
	static Scanner sc = new Scanner(System.in);

}
