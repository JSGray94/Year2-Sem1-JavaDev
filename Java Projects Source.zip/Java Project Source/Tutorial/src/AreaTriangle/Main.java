package AreaTriangle;

public class Main {

	public static void main(String[] args) {
		
		//Declare variables.
		double base;
		double height;
		
		System.out.println("Enter the triangles base: ");
		base = TriangleArea.sc.nextDouble();	//Base declared and filled.
		
		System.out.println("Enter the triangles height: ");
		height = TriangleArea.sc.nextDouble();	//height declared and filled.
		
		double preArea = base * height;
		//Divide by 2
		double area = preArea / 2;	//Calc area.
		
		//Display answer.
		System.out.println("The area of your triangle is: " + area);
		
	}

}
