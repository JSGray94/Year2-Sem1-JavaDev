package CustomMethodReturn;

import java.util.Scanner;

public class Main {

	//Define scanner input.
	static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		inputTest();
		
	}
	
	//Static means it cannot be instantiated.
	public static void inputTest() {
		
		String message = input.nextLine();
		
		System.out.println(Hello(message));
	}
	
	//Takes in a string parameter and returns a string.
	public static String Hello(String message) {
		
		//If message input is "Hi" return "Hello"
		if(message.equals("Hi")) {
			
			return "Hello";
		}
		else {
			return "Goodbye";
		}
	}

}

