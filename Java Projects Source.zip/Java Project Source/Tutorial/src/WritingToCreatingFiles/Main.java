package WritingToCreatingFiles;

/*
 * how to write to files and create files.
 */

import java.io.BufferedReader;	//Scanner
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.File;

//Class Main
public class Main {
	
	
	
	//Main entry point
	public static void main(String[] args) throws Exception {
		
		//Creates a new file and assigns a path/name,
		File newFile = new File("WrittenFile.txt");
		//Tests to see if file exists.
		if(newFile.exists()) 
			System.out.println("File: WrittenFile.txt exists. ");
		else {
			try {
				newFile.createNewFile();
			} catch(Exception e) {
				
				e.printStackTrace();
			}
		}
		
		//Create a new file writer.
		try{
			//Creates new file writer object.
			FileWriter fw = new FileWriter(newFile);
			//Creates new buffered writer object and the file writer is passed in.
			BufferedWriter bw = new BufferedWriter(fw);
			//Write the string to be written into the file.
			bw.write("This has been written into a file.");
			bw.close(); 	//Close.
			//Test to see if file has been written.
			System.out.println("File Written. ");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

}
