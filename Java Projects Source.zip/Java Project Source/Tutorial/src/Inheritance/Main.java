package Inheritance;

public class Main {

	public static void main(String[] args) {
		
		//Creates a basic bank account object
		BankAccount ba = new BankAccount("Jordan", 10000);
		l(ba.getOwner());
		l(ba.getBalance());
		//End of basic bank account
		l("//--------------------------------------------------------------------//");
		//Creates a savings account object
		SavingsAccount sa = new SavingsAccount("Bob", 100);
		sa.deposit(10);
		sa.addInterest();
		l(sa.getOwner());
		l(sa.getBalance());
		//End of savings account.
		l("//--------------------------------------------------------------------//");
		//Creates a checking account object
		CheckingAccount ca = new CheckingAccount("Jimmy", 200.00, 20);
		ca.withdraw(25);
		ca.useCheck();
		l(ca.getOwner());
		l(ca.getBalance());
		//End of savings account
		l("//--------------------------------------------------------------------//");
		//CheckingAccountWFees object
		CheckingAccountWFees caf = new CheckingAccountWFees("George", 300, 10);
		caf.withdraw(25);
		caf.deductFees();
		caf.useCheck();
		//End of this account.
		
		//Uses below method to display all accounts owners and balance.
		lol(ba);
		lol(sa);
		lol(ca);
		lol(caf);
		
	}
	
	//Makes use of inheritance to print off everything.
	public static void lol(BankAccount f) {
		
		l(f.getOwner());
		l(f.getBalance());
		
	}
	
	//Basic print method
	public static void l(Object s){
		
		System.out.println(s);
	}

}

