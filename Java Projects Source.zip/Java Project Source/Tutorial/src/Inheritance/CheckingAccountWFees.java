package Inheritance;

public class CheckingAccountWFees extends CheckingAccount {
	
	//Declare variables
	private final double FEES = 20.00;
	
	//Constructor (Default)
	public CheckingAccountWFees() {
		
		super();
	}
	//Constructor (custom)
	public CheckingAccountWFees(String owner, double initialBalance, int remainingChecks) {
		
		super(owner, initialBalance, remainingChecks);
	}
	
	public void deductFees() {
		
		this.withdraw(FEES);
	}
}
