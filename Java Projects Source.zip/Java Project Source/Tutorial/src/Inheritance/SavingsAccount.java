package Inheritance;

public class SavingsAccount extends BankAccount {

	//Interest rate in the savings account.
	//Finals do not change.
	private final double INTEREST_RATE = 0.05;
	
	//Basic constructor
	public SavingsAccount() {
		//Calls constructor of prev class
		//Same as coding "BanckAccount = new BankAccount"
		super();
	}
	
	public SavingsAccount(String owner, double initialBalance) {
		
		super(owner, initialBalance);
	}
	
	//Take current amount and increase by interest rate.
	public void addInterest() {
		
		double increaseBy = (this.getBalance() * INTEREST_RATE);
		this.deposit(increaseBy);
	}
	
}
