package Inheritance;

public class CheckingAccount extends BankAccount {
	
	//Define variables.
	private int _remainingChecks;
	
	//Default constructor
	public CheckingAccount() {
		super();		//Calls default constructor.
		_remainingChecks = 100;	//Sets remaining checks variable
	}
	//
	public CheckingAccount(String owner, double initialBalance, int remainingChecks) {
		
		//Always call super on first line.
		super(owner, initialBalance);
		this._remainingChecks = remainingChecks;
	}
	//Sub a check
	public void useCheck() {
		
		_remainingChecks --;
	}
	//Add a check
	public void getCheck() {
		
		_remainingChecks ++;
	}
	
	
	
	
}
