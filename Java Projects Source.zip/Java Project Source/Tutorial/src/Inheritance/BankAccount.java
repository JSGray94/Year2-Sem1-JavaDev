package Inheritance;

public class BankAccount {
	
	//Define variables.
	private String _owner;
	private double _balance;
	
	//Constructor (Default)
	public BankAccount() {
		
		_owner = "Bob Bill";
		_balance = 0.00;
		
	}
	//Constructor (Custom)
	public BankAccount(String owner, double balance) {
		
		this._owner = owner;
		this._balance = balance;
	}
	//Deposit money into account.
	public void deposit(double amount) {
		
		_balance += amount;
	}
	//Withdraw money from the account.
	public void withdraw(double amount) {
		
		_balance -= amount;
	}
	
	//Getters
	public String getOwner() {
		
		return this._owner;
	}
	public double getBalance() {
		
		return this._balance;
	}
}
