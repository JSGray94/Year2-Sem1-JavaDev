package StringFormatting;

import java.util.*;

public class StringFormattingTest {

	public static void main(String[] args) {
		
		//format1();	
		
		//format2();
		
		//format3();
		
		//format4();
		
	}
	
	public static void format4() {
		
		String nameOutput = "Your naame is: %40s\n";
		
		System.out.println("What is your name?: \n");
		Scanner s = new Scanner(System.in);
		String userName = s.nextLine();
		String shortName = "Alex";
		String longName = "PoopHeadMcGeeLikesSpongebobSquarepants";
		System.out.printf(nameOutput, userName);
		System.out.printf(nameOutput, shortName);
		System.out.printf(nameOutput, longName);

	}
	
	public static void format3() {
		
		double longDecimal = 3.1436789;
		
		System.out.printf("%.2f\n", longDecimal);
	}
	
	public static void format2() {
		
		for(int i = 0; i < 10; i++) {
			for(int j = 11; j < 20; j++) {
				
				System.out.printf("%d + %d = %d\n", i, j, (i + j));
			}
			
		}
	}

	public static void format1() {
		
		for(int i=1; i < 100; i++) {
			//Format strings look like: %[flag][width][.precision][type]
			//Right aligns i
			System.out.printf("Your Number: %03d\n", i);
		}
	}
	
}
