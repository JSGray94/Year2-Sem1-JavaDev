package AppletsAndGraphics;

import java.applet.Applet;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.geom.Ellipse2D;


public class Main extends Applet {

	//Main entry point
	public void paint(Graphics g) {
		
		Graphics2D g2 = (Graphics2D)g;
		//(x window, y window, size x, size y)
		Ellipse2D.Double e = new Ellipse2D.Double(0, 0, 300, 300);	//Creates a ellipse in the applet window.
		//Generate a circle
		g2.draw(e);
	}

}
