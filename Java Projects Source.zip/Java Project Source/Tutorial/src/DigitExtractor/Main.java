package DigitExtractor;

import java.util.Scanner;

public class Main {

	int tNumber = 0;
	String sNumber = "";
	
	static Scanner input = new Scanner(System.in);	//User input.
	
	//Basic constructor
	//Takes user input and sets it to total number.
	public Main(int numberSequence) {
		
		tNumber = numberSequence;
	}
	public Main(String numberSequence) {
		
		sNumber = numberSequence;
	}
	
	public void returnInvertedOrderByMath() {
		
		int integer1;
		int integer2;
		int integer3;
		int integer4;
		int integer5;
		
		integer1 = (tNumber%10);
		integer2 = (tNumber%100) / 10;
		integer3 = (tNumber%1000) / 100;
		integer4 = (tNumber%10000) / 1000;
		integer5 = (tNumber%100000) / 10000;
		
		System.out.println(integer1 + "\n"
				+ integer2 + "\n"
				+ integer3 + "\n"
				+ integer4 + "\n"
				+ integer5 + "\n");
	}
	
	public void returnInvertedOrderByString() {
		
		char p1;
		char p2;
		char p3;
		char p4;
		char p5;
		
		//12345
		p1 = sNumber.charAt(4);
		p2 = sNumber.charAt(3);
		p3 = sNumber.charAt(2);
		p4 = sNumber.charAt(1);
		p5 = sNumber.charAt(0);
		
		System.out.println(p1 + "\n" + p2 + "\n" + p3 + "\n" + p4 + "\n" + p5);

	}
	
	public static void main(String[] args) {
		
		System.out.println("Welcome to the digit extractor, please enter 5 digits: ");
		String in = input.nextLine();	//Get string value of input.
		System.out.println("Mathematically: ");
		Main deMath = new Main(Integer.parseInt(in));	//Casts user input to an int from string.
		deMath.returnInvertedOrderByMath();
		System.out.println("Using strings/conceptually: ");
		Main deConceptual = new Main(in);
		deConceptual.returnInvertedOrderByString();
		
	}

}
