package DetectingMouseClicksApplet;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


//Everytime the user clicks, display a dot.
public class MouseListenerTutorial extends Applet implements MouseListener {
	
	private Graphics globalGraphics = null;
	
	//Initialises mouselistener.
	public void init() {
		
		this.addMouseListener(this);
	}
	
	//Code is executed in the applet here.
	public void paint(Graphics g) {
		
		//Set size off applet.
		this.setSize(new Dimension(800, 600));
		
			globalGraphics = g.create();
	}
	//Draws dots where clicked
	public void drawDot(int x, int y, int width, int height) {
		
		//Random number between 1 - 254
		//represent colour
		int r = (int) (Math.random() * 255);
		int g = (int) (Math.random() * 255);
		int b = (int) (Math.random() * 255);
		
		Color randomColor = new Color(r, g, b);
		
		globalGraphics.setColor(randomColor);
		globalGraphics.fillRect(x, y, width, height);
		
		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		
		//Tests if control is held down.
		boolean isControl = e.isControlDown();
		//Get x and y coords.
		int getX = e.getX();
		int getY = e.getY();
		//Tests if control is held down
		if(isControl)
			//Call draw dot, takes in x and y.
			drawDot(getX, getY, 20, 20);
		else if(e.getButton() == 3)
			drawDot(getX, getY, 50, 50);
		else
			drawDot(getX, getY, 10, 10);
		
		System.out.println(e.getButton());
		
		
		
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {

		System.out.println("Mouse entered. ");
	}
	@Override
	public void mouseExited(MouseEvent e) {

		System.out.println("Mouse exited. ");
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
