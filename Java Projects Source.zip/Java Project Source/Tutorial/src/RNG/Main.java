package RNG;

import java.util.Random;

public class Main {

	public static void main(String[] args) {
		
		//Create new instance of random.
		Random rnd = new Random();
		System.out.println(rnd.nextInt(100));	//Displays random int from 0 - 100
		
		
	}

}
