package Recursion;

public class FibonacciSeqTest {

	public static long fibonacci(int index) {
		
		if(index == 0)
			return 0;
		if(index <= 2)
			return 1;
		
		long fibTerm = fibonacci(index - 1) + fibonacci(index -2);
		return fibTerm;
	}
	
	public static void main(String[] args) {
		
		int in = 0;		
		
		while(true) {
			
			System.out.println(fibonacci(in));
			in++;
		}
		
	}

}
