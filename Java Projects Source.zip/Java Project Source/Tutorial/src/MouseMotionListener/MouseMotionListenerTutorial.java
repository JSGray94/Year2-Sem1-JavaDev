package MouseMotionListener;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;

public class MouseMotionListenerTutorial extends Applet implements MouseMotionListener, MouseListener {
	
	//
	private Graphics globalGraphics;
	
	private int mouseButton = 0;
	
	//Always runs before paint().
	public void init() {
		
		//Tells the program to use itself
		this.addMouseMotionListener(this);
		
		this.addMouseListener(this);
	}
	
	//Executable method.
	public void paint(Graphics g) {
		
		//set size of applet
		this.setSize(new Dimension(500, 500));
		globalGraphics = g.create();
		
		
	}
	
	//Draws a circle.
	public void drawCircle(int x, int y, int width, int height) {
		
		globalGraphics.setColor(getRandomColor());
		Ellipse2D circle = new Ellipse2D.Double((double) x, (double) y, (double) width, (double) height);
		Graphics2D g2 = (Graphics2D) globalGraphics;
		g2.fill(circle);
	}
	
	public void drawSquare(int x, int y, int width, int height) {
		
		globalGraphics.setColor(getRandomColor());
		globalGraphics.fillRect(x, y, width, height);
		
	}
	
	//generate a random color.
	public Color getRandomColor() {
		
		int red = (int)(Math.random() * 256);
		int green = (int)(Math.random() * 256);
		int blue = (int)(Math.random() * 256);
		
		return new Color(red, green, blue);

	}

	public void mouseAction(MouseEvent e) {
		
		int mouseX = e.getX();
		int mouseY = e.getY();
		
		if(mouseButton == MouseEvent.BUTTON3 || mouseButton == MouseEvent.BUTTON3_MASK)
			drawSquare(mouseX, mouseY, 20, 20);
		else
			drawCircle(mouseX, mouseY, 20, 20);
	}
	
	//Mouse held and moved
	@Override
	public void mouseDragged(MouseEvent e) {
	
		mouseButton = e.getModifiers();
		mouseAction(e);
	}

	//Mouse moved.
	@Override
	public void mouseMoved(MouseEvent e) {
		
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		mouseButton = e.getButton();
		mouseAction(e);
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}
