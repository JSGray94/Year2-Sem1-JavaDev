package SwitchStatement;

public class SwitchStatementTest {

	public static void main(String[] args) {
		
		int day = 4;
		String dayString = "";
		String wednesdaySub = "Wednsday sub. ";
		
		switch(day) {
		
		case 0:
			dayString = "Sunday";
			break;
		case 2:
			dayString = "Monday";
			break;
		case 3:
			dayString = "Tuesday";
			break;
		case 4:
			if(wednesdaySub != null) 
				dayString = wednesdaySub;
			else
				dayString = "Wednesday";
			break;
		case 5: 
			dayString = "Thursday";
			break;
		case 6:
			dayString = "Friday";
			break;
		case 7: 
			dayString = "Saturday";
			break;
		default:
			dayString = "Error: Not a valid int. ";
			break;
			
		
		}
		
		System.out.println(dayString);
		
	}

}
