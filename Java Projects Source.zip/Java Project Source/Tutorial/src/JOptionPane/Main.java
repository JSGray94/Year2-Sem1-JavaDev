package JOptionPane;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		//Get user input as a double.
		double number = Double.parseDouble(JOptionPane.showInputDialog("What is 3/2? "));
		
		
		if((number - 1.5) < .00001) {
			
			//If user inputs 1.5 tell they are correct
			JOptionPane.showMessageDialog(null, "You are correct!");
		}
		else {
			
			JOptionPane.showMessageDialog(null, "You are incorrect!");
		}
		
	}

}
