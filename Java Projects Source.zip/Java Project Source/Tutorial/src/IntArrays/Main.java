package IntArrays;

public class Main {

	public static void main(String[] args) {
		
		//Create an integer with 5 slots.
		int arrInt[] = new int[5];
		//Set int @ index 0 to 1
		arrInt[0] = 1;
		
		int i = 1;
		
		//Sets each array.
		while(i <= 4) {
			
			arrInt[i] = i+1;
			i++;
		}
		
		
	}

}
