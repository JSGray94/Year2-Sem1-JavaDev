package ArrayLists;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	// Reads user input.
	static Scanner reader = new Scanner(System.in);
	// A new arraylist that holds integers
	static ArrayList<Integer> array = new ArrayList<Integer>();

	public static void printArray() {

		System.out.println("//------------------------------------------------//");
		// Scroll through each item in the array.
		for (int i : array) {

			System.out.println(i);
		}

	}

	public static void main(String[] args) {

		System.out.println("Enter an array of numbers, type 0 when finished: ");

		int in = reader.nextInt();

		while (in != 0) {

			array.add(in);
			in = reader.nextInt();
		}
		
		//Print the array
		printArray();

		// User typed 0.
		System.out.println("//-----------------------------------------------------//");

		//Delete a number
		System.out.println("What number would you like to delete? ");
		int del = reader.nextInt();
		for(int i = 0; i<array.size(); i++) {
			
			if(array.get(i) == del) {
				
				array.remove(i);
				break;

			}
					}
		
		printArray();

	}

}
