package ReadingFromFiles;

/*
 * how to read text from files.
 */

import java.io.BufferedReader;	//Scanner
import java.io.FileReader;

//Class Main
public class Main {
	
	
	
	//Main entry point
	public static void main(String[] args) throws Exception {
		
		//New file reader
		FileReader file = new FileReader("readme.txt");
		//Scanner reader.
		BufferedReader reader = new BufferedReader(file);	//Reads file into reader.
		
		String text = "";
		String line = reader.readLine();	//Each read line stored into line string.
		//Reads through each line until an empty line is reached.
		while(line != null) {
			
			text += line;
			line = reader.readLine();
		}
		
		//Close reader after use
		reader.close();
		//Print file to console
		System.out.println(text);
		
	}

}
