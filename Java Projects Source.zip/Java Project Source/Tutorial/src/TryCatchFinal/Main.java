package TryCatchFinal;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;

/*
 * Using try and catch.
 */

public class Main {

	// Code executed here.
	public static void main(String[] args) throws IOException {
		
		BufferedReader reader = null;
		
		try {
		
			reader = new BufferedReader(new FileReader(new File("text.txt")));
			String contents = reader.readLine();
			System.out.println(contents);
			reader.close();
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
		//This executes even when error occurs.
		finally {
			
			if(reader != null)
				reader.close();	//Still need to close br.
		}
		
		
	}

}
