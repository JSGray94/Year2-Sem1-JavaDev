package KeyListener;

import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

public class KeyListenerTutorial extends Applet implements KeyListener {

	private Rectangle rect; //Rectangle that moves
	private ArrayList<Integer> keysDown;
	
	//Runs before paint method.
	public void init() {
		
		setFocusable(true);
		
		rect = new Rectangle(0, 0, 50, 50);
		
		keysDown = new ArrayList();
		this.addKeyListener(this);
	}
	
	//Main method
	public void paint(Graphics g) {
		
		//Set applet size 
		setSize(500, 500);
		
		//Convert to graphics 2D
		Graphics2D g2 = (Graphics2D) g;
		g2.fill(rect);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(!keysDown.contains(e.getKeyCode()))
			keysDown.add(new Integer(e.getKeyCode()));
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
		keysDown.remove(new Integer(e.getKeyCode()));
		
	}
	
	//Responsible for moving rectangle.
	public void moveRect() {
		
		int x = rect.x;
		int y = rect.y;
		
		if(keysDown.contains(KeyEvent.VK_UP))
			y -= 2;
		if(keysDown.contains(KeyEvent.VK_DOWN))
			y += 2;
		if(keysDown.contains(KeyEvent.VK_LEFT))
			x -= 2;
		if(keysDown.contains(KeyEvent.VK_RIGHT))
			x += 2;
		
		rect.setLocation(x, y);
		repaint();
			
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generatd method stub
		
	}

}
