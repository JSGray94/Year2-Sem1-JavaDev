package Enumerations;

import java.util.Scanner;

public class EnumTest {

	//Takes user input.
	static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		
		System.out.println("1) Print the current year: \n"
				+ "2) Print the programming language currently in: \n"
				+ "3) Print the first few digits of Pi: \n"
				+ "4) Print the first few terms of the fibonacci sequence: ");
		
		int option = input.nextInt();
		
		if(option == Enumerations.PRINT_CURRENT_YEAR) {
			
			System.out.println("2015");
		}
		else if(option == Enumerations.PRINT_FIB) {
			
			System.out.println("0 1 1 2 3 5 8 13 21");
		}
		else if(option == Enumerations.PRINT_LANGUAGE) {
			
			System.out.println("Java");
		}
		else if(option == Enumerations.PRINT_PI) {
			
			System.out.println("3.14");
		}
		else {
			
			System.out.println("Not an option...");
		}
		
		//Returns to beginning
		main(args);
	}

}

class Enumerations {
	
	public static final int PRINT_CURRENT_YEAR = 1;
	public static final int PRINT_LANGUAGE = 2;
	public static final int PRINT_PI = 3;
	public static final int PRINT_FIB = 4;

	
}
