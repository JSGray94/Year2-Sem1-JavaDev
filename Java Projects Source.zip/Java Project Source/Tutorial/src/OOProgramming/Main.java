package OOProgramming;

public class Main {

	//Declare variables
	int tWater = 0;
	
	//Default constructor
	public Main() {
		
	}
	//Constructor requires int input.
	public Main(int waterAmount) {
		
	}
	//Adds amount to total water
	public void addWater(int amount) {
		
		tWater += amount;
	}
	//Subtracts water from total
	public void subWater(int amount) {
		
		tWater -= amount;
	}
	//Returns the total water
	public int getWater() {
		
		return tWater;
	}
	
	public static void main(String[] args) {
		
		String x = "Hello";
		
		//Creates a new Main object, represents water bottle.
		//0 Water in this.
		Main waterBottle = new Main(0);
		
		waterBottle.addWater(100);	//Add 100 to water.
		waterBottle.subWater(20);	//Subtract 20 water.
		System.out.println("Your remaining water: " + waterBottle.getWater());
		
	}

}
