package Images;

import java.applet.Applet;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.net.URL;

public class ImageTester extends Applet {

	private Image _thisImage = null;
	
	public void paint(Graphics g) {
		
		//Set size of applet.
		this.setSize(640, 480);
		
		//If the image hasn't been loaded yet then load the image.
		if(_thisImage == null) 
			_thisImage = getImage("image.png");
		
		//Cast the passed in Graphics object to a Graphics2D object and set it to g2.
		//Draw the new image
		Graphics2D g2 = (Graphics2D)g;
		g2.drawImage(_thisImage, 50, 50, 25, 25, this);
		
	}
	
	//Returns an image object.
	//Takes in a file path.
	public Image getImage(String path) {
		
		//Create a temporary image to save URL to.
		Image tempImage = null;
		//Try loading the path for the file and catch any exceptions.
		try {
			
			URL imageURL = ImageTester.class.getResource(path);
			tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
					
		}catch (Exception e){
			
			System.out.println("Error occured during loading file. \n" + e.getMessage());
		}
		//Return Image
		return tempImage;
	}

}
