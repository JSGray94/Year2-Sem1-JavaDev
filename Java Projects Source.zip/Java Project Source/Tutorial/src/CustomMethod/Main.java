package CustomMethod;

import java.util.Scanner;

public class Main {

	//Define scanner input.
	static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		inputTest();
		
	}
	
	//Static means it cannot be instantiated.
	public static void inputTest() {
		
		String message = input.nextLine();
		if(message.equals("Hi")){
			
			System.out.println("Hello");
		}
	}

}
