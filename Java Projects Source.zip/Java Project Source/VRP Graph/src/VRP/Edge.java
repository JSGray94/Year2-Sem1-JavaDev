package VRP;

public class Edge {
	
	private Node end1;
	private Node end2;
	private int weight;
	
	//Constructor, all edges must link 2 nodes and specify a weight.
	public Edge(Node e1, Node e2, int w) {
		end1 = e1;
		end2 = e2;
		weight = w;
	}
	
	//Return the node connected to the opposite end of the edge.
	public Node navigate(Node thisEnd) {
		if(thisEnd == end1)
			return end2;
		else
			return end1;
	}
	
	//Get/Set weight.
	public void setWeight(int val) {
		weight = val;
	}
	public int getWeight() {
		return weight;
	}

}
