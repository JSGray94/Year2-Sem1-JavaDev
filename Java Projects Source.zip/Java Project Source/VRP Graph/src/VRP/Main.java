package VRP;

import java.util.ArrayList;
import java.util.Collections;

public class Main {
	
	//Create a list that stores Nodes to visit.
	private static ArrayList<Node> toVisit = new ArrayList<Node>();
	//Create a list that stores nodes that have been seen.
	private static ArrayList<Node> seen = new ArrayList<Node>();

	//An implementation of Dijkstras algorithm
	//Takes in source node.
	public static void runDijkstra(Node source) {
		
		//Source is starting node.
		source.setLabel(0);
		//Add source node in toVisit Array initially.
		toVisit.add(source);
		
		//Run while no nodes left to visit.
		while(toVisit.size() > 0) {
			//Current node is at head of toVisit again
			Node current = toVisit.remove(0);
			//Make sure this node isnt added toVisit again.
			seen.add(current);
			//All nodes directly linked to this node.
			for(Node neighbour : neighbours) {
				//Only deal with neighbours that havent bee sseen yet.
				if(!seen.contains(neighbour)) {
					//WeightTo returns the weight of the link between current and neighbour.
					//Returns -1 if no link exists.
					
					//Update label of neighbour if path via current is less than current path.
					if((dist+current.getLabel() < neighbour.getLabel()))
						neighbour.setLabel((dist + current.getLabel()));
					
					//Add neighbour toVisit if not already in list.
					if(toVisit.indexOf(neighbour) == -1)
						toVisit.add(neighbour);
				}
			}
			//Sort toVisit to ensure that next current node will be the one with the lowest
			//label value.
			Collections.sort(toVisit);
			
		}
		
	}
	
	public static void main(String[] args) {

		//** USING DIJKSTRAS ALGORITHM **
		
		//Create graph
		Graph alphaGraph = new Graph();
		
		//Add some users.
		//Create new node. Set nodes attributes. Add node the the graph.
		Node alphaNodeA = new Node();
		alphaNodeA.setAttribute("Name", "A");
		alphaGraph.addNode(alphaNodeA);
		
		Node alphaNodeB = new Node();
		alphaNodeB.setAttribute("Name", "B");
		alphaGraph.addNode(alphaNodeB);
		
		Node alphaNodeC = new Node();
		alphaNodeC.setAttribute("Name", "C");
		alphaGraph.addNode(alphaNodeC);
		
		Node alphaNodeD = new Node();
		alphaNodeD.setAttribute("Name", "D");
		alphaGraph.addNode(alphaNodeD);
		
		//Make some connections - will generate edges.
		alphaGraph.connect(alphaNodeA, alphaNodeB, 6);
		alphaGraph.connect(alphaNodeA, alphaNodeC, 2);
		alphaGraph.connect(alphaNodeB, alphaNodeC, 3);
		alphaGraph.connect(alphaNodeB, alphaNodeD, 5);
		alphaGraph.connect(alphaNodeC, alphaNodeD, 9);

		
		//Print out our network (Only shows edges).
		System.out.print("AlphaGraph\n" + alphaGraph);
				
		//Use graph structure to find nodes connected to person 1
		for(Edge e : alphaNodeA.getConnections()) {
			System.out.println(e.navigate(alphaNodeA));
		}
		
	}

}
