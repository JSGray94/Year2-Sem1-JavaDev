package VRP;

import java.util.ArrayList;

public class Graph {
	
	/*
	 * Represents a simple graph structure
	 * Comprises Nodes and Edges
	 */

	//The list of all nodes that make up the graph.
	private ArrayList<Node> nodes = new ArrayList<Node>();
	
	//Add new node to the graph
	public void addNode(Node newNode) {
		nodes.add(newNode);
	}
	
	//Return list of all nodes.
	public ArrayList<Node> getNodes() {
		return nodes;
	}
	
	//Create  connection between 2 Nodes, with specified node.
	public void connect(Node n1, Node n2, int weight) {
		Edge newEdge = new Edge(n1, n2, weight);
		n1.connect(newEdge);
		n2.connect(newEdge);
	}
	
	//Return a string representation, a list of nodes.
	public String toString() {
		String buffer = "";
		
		for(Node n : nodes)
			buffer = buffer + n + "\n";
		
		return buffer;
	}
}
