package VRP;

import java.util.ArrayList;
import java.util.HashMap;

public class Node {

	private HashMap<String, Object> attributes;	//Attributes associated with this node.
	private ArrayList<Edge> connections;	//Edges that connect to this node.
	private int label;

	//Constructor
	public Node() {
		attributes = new HashMap<String, Object>();
		connections = new ArrayList<Edge>();
	}
	
	//Set/get attributes
	public void setAttribute(String key, Object value) {
		attributes.put(key, value);
	}
	public Object getAttribute(String key) {
		return attributes.get(key);
	}
	
	//Connect an edge to this node.
	public void connect(Edge anEdge) {
		connections.add(anEdge);
	}
	
	//Return list of all edges connected to this node
	public ArrayList<Edge> getConnections() {
		return connections;
	}
	
	//Return a string representation of the node.
	//List all attributes key/value pairs.
	public String toString() {
		String buffer = "";
		for(String k : attributes.keySet()) {
			Object v = attributes.get(k);
			buffer = k + " = " + v.toString();
		}
		
		return buffer;
	}
	
	//Get nodes neighbours.
	public Node getNeighbours() {
		
		
		
	}

	//Getters and setters.
	public int getLabel() {
		return label;
	}
	public void setLabel(int label) {
		this.label = label;
	}
}
