package jUnitTests;

public class Student extends Person {
	
	private double matricNumber;

	public double getMatricNumber() {
		return this.matricNumber;
	}

	public void setMatricNumber(double matricNumber) {
		this.matricNumber = matricNumber;
	}
	
	

}
