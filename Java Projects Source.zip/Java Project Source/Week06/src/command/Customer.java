package command;

public class Customer {
	public static void main(String[] args) {
		Chef chef = new Chef();
		Waitress waitress= new Waitress();
		
		FoodOrder myStarter = new SoupOrder(chef);
		FoodOrder myMain = new SteakOrder(chef);
		
		//waitress.introduceYourself();
		waitress.takeOrder(myStarter);
		waitress.takeOrder(myMain);
		
		waitress.haveAFagBreak();
		
		waitress.popinToTheKitchen();

	}

}
