package ThreadsPractice;

public class Main {

	public static void main(String[] args) {

		Thread t1 = new Thread(new Technician("Jimmy", "error 106"));
		Thread t2 = new Thread(new Technician("John", "error 404"));
		Thread t3 = new Thread(new Technician("Bob", "error 708"));
		Thread t4 = new Thread(new Technician("Nick", "error 115"));
		Thread t5 = new Thread(new Technician("Matt", "error 111"));
		Thread t6 = new Thread(new Technician("Andrew", "error 106"));
		Thread t7 = new Thread(new Technician("Lyle", "error 321"));

		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		t6.start();
		t7.start();


		
		
	}

}
