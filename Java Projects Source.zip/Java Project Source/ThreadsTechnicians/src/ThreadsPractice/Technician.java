package ThreadsPractice;

import java.util.Random;

public class Technician implements Runnable {
	
	//basic constructor.
	public Technician(String name, String problem)
	{
		//Setters and getters.
		setName(name);
		setProblem(problem);
		setTime(this.rand.nextInt(4000));
	}

	//Technician class attributes..
	private String _name;
	private String _problem;
	private int _time;
	Random rand = new Random();
	
	public void run() {

		try {
			System.out.println("Hi, I am " + this._name + " your problem is " +this._problem + " it will take me " + this._time + " long to solve.");
			Thread.sleep(this._time);
			System.out.println(this._problem + " has been solved! ");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	//Setters and getters.
	public String getName() {
		return this._name;
	}

	public void setName(String name) {
		this._name = name;
	}

	public int getTime() {
		return this._time;
	}

	public void setTime(int time) {
		this._time = time;
	}
	
	public String getProblem() {
		return this._problem;
	}
	
	public void setProblem(String problem) {
		this._problem = problem;
	}

	
	
}
