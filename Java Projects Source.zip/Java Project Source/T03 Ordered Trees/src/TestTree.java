import java.util.*;


public class TestTree {

	public static void main(String[] args) {

		Tree t = new Tree("Fiona",
				new Tree("Diana",new Tree(),new Tree()),
				new Tree("Tim", new Tree(),new Tree()));
		System.out.println(t);
		
		
		
	}

}
