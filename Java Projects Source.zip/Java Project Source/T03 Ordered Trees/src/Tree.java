//Main class tree
public class Tree{
	
	//Tree parameters
	public String val;
	public boolean empty;
	public Tree left;
	public Tree right;
	//Basic constructor, takes no arguements and returns true if empty.
	public Tree()
	{
		empty=true;
	}
	//Constructor, takes 3 arguements and sets left node and right node.
	public Tree(String v,Tree l,Tree r)
	{
		empty = false;
		val = v;
		left = l;
		right = r;
	}
	//Print values
	public String toString()
	{
		if (empty) return "nil";
		return val+"("+left+","+right+")";
	}
	//Count nodes in a the tree
	int countLeaves(Tree node){
		  if( node == null )
		    return 0;
		  if( node.left == null && node.right == null ) {
		    return 1;
		  } else {
		    return countLeaves(node.left) + countLeaves(node.right);
		  }
		}
}
