
public class Decaf extends Coffee {

}
