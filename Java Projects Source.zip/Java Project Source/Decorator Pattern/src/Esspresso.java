
public class Esspresso extends Coffee {

}
