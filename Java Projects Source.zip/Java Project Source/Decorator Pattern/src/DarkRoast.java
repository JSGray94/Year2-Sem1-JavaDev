
public class DarkRoast extends Coffee {

}
