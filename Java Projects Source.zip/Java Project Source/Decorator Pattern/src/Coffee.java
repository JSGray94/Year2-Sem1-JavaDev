
public abstract class Coffee {
	
	//Additional attributes to be added to sub classes.
	boolean _milk;
	boolean _cream;
	boolean _chocolate;
	boolean _syrup;
	
	

}
