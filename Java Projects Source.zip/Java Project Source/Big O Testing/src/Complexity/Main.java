package Complexity;

public class Main {
	
	//This method takes in an array and linearly combs through to find the smallest number in the array.
	static int  compareSmallestNumber (int[] array)
	{
		// Set smallest value to first item in array, use curMin to keep track
		// of the smallest value found so far
		int smallestSoFar = array[0];

		//iterate through array to find smallest value
		for (int x = 1; x < array.length; x++)
		{
			if( array[x] < smallestSoFar)  
			{
				smallestSoFar = array[x];
			}
		}
		// return smallest value in the array
		return smallestSoFar;
	}

	//
	static int compareToAllNumbers (int[] array)
	{
		boolean isMin;
		//iterate through each element in array,

		int x=0;
		for (x = 0; x < array.length; x++)
		{
			isMin = true;
			for (int y = 0; y < array.length; y++)
			{
			/* compare the value in array[x] to the other values if we find that array[x] is greater than any of the 
			values in array[y] then we know that the value in array[x] is not the minimum
			remember that the 2 arrays are exactly the same, we are just taking out one value with index 'x' and 
			comparing to the other values in the array with  index 'y'
			*/
				if( array[x] > array[y])
					isMin = false;	
			}
			if(isMin)
				break;
		}
		return array[x];
	}


	public static void main(String[] args) {
		
		//Create an array to be tested
		int[] myArray = new int[100000000];
		
		
		//Uses a nested for loop with complexity "O(n^2)"
		double start = System.currentTimeMillis();
		System.out.println(compareToAllNumbers(myArray));
		double time = System.currentTimeMillis() - start;
		System.out.println("Time for compareAllNumbers: "+time);

		//Has complexity "O(n)"
		start = System.currentTimeMillis();	//Reset the start double to current time.
		System.out.println(compareSmallestNumber(myArray));
		time = System.currentTimeMillis() - start;	//Calculate how long the function inbetween took
		System.out.println("Time for compareSmallestNumber: "+time);

		
		
	}

}
