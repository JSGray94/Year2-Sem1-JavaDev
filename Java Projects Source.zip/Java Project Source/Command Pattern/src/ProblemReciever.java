import java.util.ArrayList;

public class ProblemReciever {

private ArrayList <TechProblem> theProblem = new ArrayList <TechProblem> ();
	
	public void takeProblem(TechProblem theProblem) {
		this.theProblem.add(theProblem);
	}
	
	public void giveToTechnician() {
		for(TechProblem problem : this.theProblem) {
			problem.solveProblem();
		}
	}
	
	public void solvingProblem() {
		System.out.println("The technician is solving your problem please wait a moment. ");
		
		try {
			Thread.sleep(5000);
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("The technician has solved your problem. Thank you! ");
	}
	
	public void introduceYourself() {
		System.out.println("Hi my name is Amy I will take your problem to the technician. ");
	}
	
}
