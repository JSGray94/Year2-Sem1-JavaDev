
public class Technician {

	public void solveProblem(String problem)
	{
		System.out.println("I am fixing the problem" +problem);
	}
	
}
