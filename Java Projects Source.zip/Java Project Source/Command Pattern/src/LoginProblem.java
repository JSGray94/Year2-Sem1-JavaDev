

public class LoginProblem extends TechProblem {

	public LoginProblem(Technician technician){
		setTechnician(technician);
	}
	
	public void solveProblem() {
		
		this.technician.solveProblem("Login Problem. ");
	}
	

}
