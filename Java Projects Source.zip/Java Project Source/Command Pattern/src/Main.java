


public class Main {

	public static void main(String[] args) {
		
		Technician technician = new Technician();
		ProblemReciever problemReciever = new ProblemReciever();
		
		TechProblem myProblem1 = new MemoryProblem(technician);
		TechProblem myProblem2 = new LoginProblem(technician);
		
		problemReciever.introduceYourself();
		problemReciever.takeProblem(myProblem1);
		problemReciever.takeProblem(myProblem2);
		
		problemReciever.solvingProblem();
		
		problemReciever.giveToTechnician();
		
	}

}
