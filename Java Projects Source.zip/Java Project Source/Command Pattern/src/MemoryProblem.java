
public class MemoryProblem extends TechProblem {

	
	public MemoryProblem(Technician technician){
		setTechnician(technician);
	}
	
	public void solveProblem() {
		
		this.technician.solveProblem("Memory problem.  ");
	}
	
}
