

public abstract class TechProblem {

protected Technician technician;
	
	public abstract void solveProblem();

	public Technician getTechnician() {
		return this.technician;
	}

	public void setTechnician(Technician technician) {
		this.technician = technician;
	}
	
	
}
