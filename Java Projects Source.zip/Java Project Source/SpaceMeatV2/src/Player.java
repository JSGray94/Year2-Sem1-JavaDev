
import java.awt.Graphics;
import java.util.Random;

public class Player extends Creature {

	// Declare game object
	private Game game;
	// Declare gui object
	private SettingsGUI gui;
	// Declare tile object.
	Tile tile;

	// Declare diet booleans
	private boolean enemyDiet;
	private boolean dogDiet;
	private boolean ratDiet;

	// Create new random object
	Random rand = new Random();

	// Default constructor
	public Player(Game game, int x, int y, int gridSize) {
		// Call creature constructor.
		super(game, x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT, gridSize);

		this.game = game;

		this.alive = true;

		this.enemyDiet = false;
		this.dogDiet = false;
		this.ratDiet = false;

		this.x = (rand.nextInt(gridSize - 1) + 1) * tile.TILE_WIDTH;
		this.y = (rand.nextInt(gridSize - 1) + 1) * tile.TILE_WIDTH;

	}

	// Update variables.
	@Override
	public void tick() {

		if (alive == true) {
			// Calls the input method.
			move();
		}
	}

	// Update screen.
	@Override
	public void render(Graphics g) {

		if (alive == true) {
			// Draw player.
			g.drawImage(Assets.player, (int) x, (int) y, width, height, null);
		}
	}

	// ---------------------------------
	// ---------------------------------

	public boolean isEnemyDiet() {
		return enemyDiet;
	}

	public void setEnemyDiet(boolean enemyDiet) {
		this.enemyDiet = enemyDiet;
	}

	public boolean isDogDiet() {
		return dogDiet;
	}

	public void setDogDiet(boolean dogDiet) {
		this.dogDiet = dogDiet;
	}

	public boolean isRatDiet() {
		return ratDiet;
	}

	public void setRatDiet(boolean ratDiet) {
		this.ratDiet = ratDiet;
	}

}