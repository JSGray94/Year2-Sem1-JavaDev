
//Game watcher object
public class GameWatcher implements GameListener {

	private int id;
	
	//Constructor
	public GameWatcher(int id) {
		
		this.id = id;
		System.out.println("GameWatcher: Created. ");
	}
	
	//Implementation of event handlers
	@Override
	public void running(GameEvent evt) {
		
		System.out.println("GameWatcher: Knows game as been run. ");
	}

	@Override
	public void notRunning(Game evt) {
		
		System.out.println("GameWatcher: Knows game has stopped running. ");
	}

}
