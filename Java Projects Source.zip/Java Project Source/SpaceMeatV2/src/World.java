
import java.awt.Graphics;

public class World {
	
	private int gridSize;
	
	private int width, height;

	private int[][] tiles;
	
	//Default constructor
	public World(String path, int size) {
		
		loadWorld(path, size);
	}
	
	//Update variables.
	public void tick() {
		
		
	}
	
	//Update graphics
	public void render(Graphics g) {
		
		for (int y = 0; y < height; y++) {
			for(int x = 0; x < width; x++) {
				
				//Call get tile method to render tiles
				//Multiply by Tiles pixels to get actual world size.
				getTile(x, y).render(g, x * Tile.TILE_WIDTH, y * Tile.TILE_HEIGHT); 
			}
		}
	}
	
	//Finds ID in tile array
	public Tile getTile(int x, int y) {
		
		Tile t = Tile.tiles[tiles[x][y]];
		
		//Only set so many tiles so this does a check on id.
		if(t == null)
			return Tile.greyTile;
		
		return t;
	}
	
	//
	private void loadWorld(String path, int gridSize) {
		
		width = gridSize;	//Set width of level
		height = gridSize;	//Set height of level
		tiles = new int[width][height];	//Set to new 2D array
		
		//For every tile position in this size world
		for(int x = 0; x < width; x++) {
			for(int y = 0; y < height; y ++) {
				
				tiles[x][y] = 0;	//Sets every tile to id 1 tile.
			}
		}
	}
	
	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

}

