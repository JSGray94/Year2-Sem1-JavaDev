
import java.awt.image.BufferedImage;

//This class' purpose is to load in assets.
public class Assets {
	
	//These represent size of each sprite in the sprite sheet.
	private static final int width = 80, height = 80;
	
	//Declare Buffered Image objects.
	public static BufferedImage deathclaw, human, player, bee, rat, dog, greyTile;

	//---------------------------------------
	//---------------------------------------
	
	//Loads everything into the game
	public static void init() {
		
		//Load in sprite sheet.
		SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/SpriteSheet.png"));
		
		//Set each object to their respective sprites in sheet.
		//Takes x, y, width, height.
		deathclaw = sheet.crop(0, 0, width, height); 
		human = sheet.crop(width, 0, width, height);
		player = sheet.crop(width * 2, 0, width, height); 
		bee = sheet.crop(0, height, width, height);
		rat = sheet.crop(width, height, width, height);
		dog = sheet.crop(width * 2, height, width, height);
		greyTile = sheet.crop(0, height * 2, width, height);
		
	}
	
}
