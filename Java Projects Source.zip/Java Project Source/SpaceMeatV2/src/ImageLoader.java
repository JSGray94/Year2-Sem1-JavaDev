
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

//This class is used solely to load images.
public class ImageLoader {
	
	//This method takes in a file path and loads that image (file)
	//Into a Buffered Image object.
	public static BufferedImage loadImage(String path) {
		
		try {
			return ImageIO.read(ImageLoader.class.getResource(path));
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1); 	//Exit game if image doesnt load
		}
		
		return null;
	}
}
