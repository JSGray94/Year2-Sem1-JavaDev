import java.awt.Graphics;

public class SpaceDog extends Creature {

	// Declare game object
	private Game game;
	// Declare gui object
	private SettingsGUI gui;
	// Declare tile object.
	Tile tile;


	// -----------------------------------
	// -----------------------------------

	// Human enemy constructor.
	public SpaceDog(Game game, int x, int y, int gridSize) {
		super(game, x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT, gridSize);

		this.game = game;
		
		this.setType("dog"); 

	}

	// ----------------------------------
	// ----------------------------------

	// Update variables
	@Override
	public void tick() {

		if (alive == true) {
			move();
		}
	}

	// Update images.
	@Override
	public void render(Graphics g) {

		if (alive == true) {
			// Draw player.
			g.drawImage(Assets.dog, (int) x, (int) y, width, height, null);
		}
	}

	// ----------------------------------
	// ----------------------------------


}
