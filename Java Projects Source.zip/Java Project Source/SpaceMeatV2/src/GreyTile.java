
import java.awt.image.BufferedImage;

//Specific type of tile
public class GreyTile extends Tile {
	//Returns grey tile sprite
	public GreyTile(int id) {
		super(Assets.greyTile, id);
		
		
	}

}
