import java.awt.Graphics;

public class SpaceRat extends Creature {

	// Declare game object
	private Game game;
	// Declare gui object
	private SettingsGUI gui;
	// Declare tile object.
	Tile tile;


	// -----------------------------------
	// -----------------------------------

	// Human enemy constructor.
	public SpaceRat(Game game, int x, int y, int gridSize) {
			super(game, x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT, gridSize);

			this.game = game;
			
			this.setType("rat");
			
		}

	// ----------------------------------
	// ----------------------------------

	// Update variables
	@Override
	public void tick() {

		if (alive == true) {
			move();
		}
	}

	// Update images.
	@Override
	public void render(Graphics g) {

		if (alive == true) {
			// Draw player.
			g.drawImage(Assets.rat, (int) x, (int) y, width, height, null);
		}
	}

	// ----------------------------------
	// ----------------------------------
	

}
