import java.util.EventListener;

//Game listener interface.
public interface GameListener extends EventListener {
	
	public void running(GameEvent evt);
	public void notRunning(Game evt);
}
