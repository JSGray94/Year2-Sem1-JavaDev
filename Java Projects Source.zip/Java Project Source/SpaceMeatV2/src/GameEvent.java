import java.util.EventObject;

//The game event.
public class GameEvent extends EventObject {

	public GameEvent(Object src) {
		super(src);
	}

}
