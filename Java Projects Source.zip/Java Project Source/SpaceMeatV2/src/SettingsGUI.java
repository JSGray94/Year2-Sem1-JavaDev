
/*-----------------------------------------------------------------------
 * Created by: Jordan Stephano Gray
 * Matric No: 40087220
 * University: Edinburgh Napier
 * Course: BSc Games Development
 * Year: 3
 * Module: Software Development 3
 * Email: graybostephano@gmail.com
 * 
 * Class SettingsGUI:
 * This is where the user can interact with the program during runtime
 * and will give a variety of options.
 ----------------------------------------------------------------------*/

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.Graphics2D;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class SettingsGUI extends JFrame implements GameListener {

	// Create JFrame object.
	private JFrame frmSpaceMeatSettings;
	private JTextField textField;
	
	//
	private int counter;
	private JTextField textFieldRat;
	private JTextField textFieldDog;
	private JTextField textFieldEnemy;

	/**
	 * Launch the application.
	 */
	public void run(Game game) {
		try {
			SettingsGUI window = new SettingsGUI(game);
			window.frmSpaceMeatSettings.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("GameWatcher SETTINGS GUI: Created. ");
	}

	/**
	 * Create the application.
	 */
	public SettingsGUI(Game game) {

		initialize(game);

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(final Game game) {
		frmSpaceMeatSettings = new JFrame();
		frmSpaceMeatSettings.setResizable(false);
		frmSpaceMeatSettings.setTitle("Space Meat Settings");
		frmSpaceMeatSettings.setBounds(900, 100, 412, 270);
		frmSpaceMeatSettings.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSpaceMeatSettings.getContentPane().setLayout(null);

		JLabel lblIntro = new JLabel(
				"<html>Welcome to Space Meat! <br> Here you can adjust the games settings before getting started.</html>");
		lblIntro.setBounds(10, 11, 414, 36);
		lblIntro.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		frmSpaceMeatSettings.getContentPane().add(lblIntro);

		JButton btnMove = new JButton("Move");
		btnMove.setBounds(255, 110, 117, 22);
		btnMove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//Runs the game
				game.tick();
				//Checks for game over.
				//Prints how many moves achieved.
				if (game.player.alive == false) {

					System.out.println("GAME OVER");
					System.out.println("Your moves this run: " + counter);
					frmSpaceMeatSettings.dispatchEvent(new WindowEvent(frmSpaceMeatSettings, WindowEvent.WINDOW_CLOSING));
					
					notRunning(game); //Notify listener that game is not running.
				}
				
				counter ++;	//Increment counter
				textField.setText(Integer.toString(counter));

			}
		});
		btnMove.setFont(new Font("Letter Gothic Std", Font.PLAIN, 11));
		frmSpaceMeatSettings.getContentPane().add(btnMove);

		JLabel lblDiet = new JLabel("Diet:");
		lblDiet.setBounds(10, 88, 46, 14);
		lblDiet.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		frmSpaceMeatSettings.getContentPane().add(lblDiet);

		textField = new JTextField();
		textField.setEditable(false);
		textField.setFont(new Font("Letter Gothic Std", Font.BOLD, 12));
		textField.setBounds(311, 148, 61, 20);
		frmSpaceMeatSettings.getContentPane().add(textField);
		textField.setColumns(10);

		JLabel lblMoves = new JLabel("Moves:");
		lblMoves.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		lblMoves.setBounds(255, 150, 46, 14);
		frmSpaceMeatSettings.getContentPane().add(lblMoves);
		
		JButton btnSpaceRodents = new JButton("Space Rodents");
		btnSpaceRodents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				game.player.setRatDiet(!game.player.isRatDiet());
				System.out.println("Player Eats Rats: " + game.player.isRatDiet()); 
				
				textFieldRat.setText(Boolean.toString(game.player.isRatDiet()));
				
			}
		});
		btnSpaceRodents.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		btnSpaceRodents.setBounds(10, 109, 140, 23);
		frmSpaceMeatSettings.getContentPane().add(btnSpaceRodents);
		
		JButton btnSpaceDog = new JButton("Space Dogs");
		btnSpaceDog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				game.player.setDogDiet(!game.player.isDogDiet());
				System.out.println("Player Eats Dogs: " + game.player.isDogDiet());
				
				textFieldDog.setText(Boolean.toString(game.player.isDogDiet()));
			}
		});
		btnSpaceDog.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		btnSpaceDog.setBounds(10, 146, 140, 23);
		frmSpaceMeatSettings.getContentPane().add(btnSpaceDog);
		
		JButton btnEnemy = new JButton("Enemies");
		btnEnemy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				game.player.setEnemyDiet(!game.player.isEnemyDiet());
				System.out.println("Player Eats Enemies: " + game.player.isEnemyDiet());
				
				textFieldEnemy.setText(Boolean.toString(game.player.isEnemyDiet()));
			}
		});
		btnEnemy.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		btnEnemy.setBounds(10, 183, 140, 23);
		frmSpaceMeatSettings.getContentPane().add(btnEnemy);
		
		textFieldRat = new JTextField();
		textFieldRat.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		textFieldRat.setText(Boolean.toString(game.player.isRatDiet()));
		textFieldRat.setEditable(false);
		textFieldRat.setBounds(160, 110, 67, 20);
		frmSpaceMeatSettings.getContentPane().add(textFieldRat);
		textFieldRat.setColumns(10);
		
		textFieldDog = new JTextField();
		textFieldDog.setEditable(false);
		textFieldDog.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		textFieldDog.setText(Boolean.toString(game.player.isDogDiet()));
		textFieldDog.setBounds(160, 147, 67, 20);
		frmSpaceMeatSettings.getContentPane().add(textFieldDog);
		textFieldDog.setColumns(10);
		
		textFieldEnemy = new JTextField();
		textFieldEnemy.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		textFieldEnemy.setText(Boolean.toString(game.player.isEnemyDiet()));
		textFieldEnemy.setEditable(false);
		textFieldEnemy.setColumns(10);
		textFieldEnemy.setBounds(160, 184, 67, 20);
		frmSpaceMeatSettings.getContentPane().add(textFieldEnemy);
		
		JLabel label = new JLabel(":");
		label.setBounds(152, 113, 13, 14);
		frmSpaceMeatSettings.getContentPane().add(label);
		
		JLabel label_1 = new JLabel(":");
		label_1.setBounds(152, 150, 13, 14);
		frmSpaceMeatSettings.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel(":");
		label_2.setBounds(152, 187, 13, 14);
		frmSpaceMeatSettings.getContentPane().add(label_2);

	}

	// ----------------------------------
	// ----------------------------------

	public JFrame getFrmSpaceMeatSettings() {
		return frmSpaceMeatSettings;
	}

	public void setFrmSpaceMeatSettings(JFrame frmSpaceMeatSettings) {
		this.frmSpaceMeatSettings = frmSpaceMeatSettings;
	}

	@Override
	public void running(GameEvent evt) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void notRunning(Game evt) {
		// TODO Auto-generated method stub
		
	}

}
