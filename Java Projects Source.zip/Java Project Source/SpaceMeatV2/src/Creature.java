import java.util.Random;

//Creature extends entity.
public abstract class Creature extends Entity {

	// Cannot change once set.
	// Default speed cannot change.
	public static final int DEFAULT_SPEED = 64;
	// Default width and height variables.
	public static final int DEFAULT_CREATURE_WIDTH = 64, DEFAULT_CREATURE_HEIGHT = 64;
	
	// Declare tile object.
	Tile tile;
	// Declare world object.
	World world;

	// ---------------------------------------
	// ---------------------------------------

	// create game object.
	private Game game;
	// Give creature health variable.
	protected boolean alive;
	// speed it moves
	protected int speed;
	// Currently moving variables.
	protected int xMove, yMove;
	//Type variable
	private String type;
	// Use these variables for generating random numbers
	Random rand;
	int randMove;
	// Use these variables for random spawning
	int randSpawn;
	// Int decides between 3 enemies to spawn
	// Part of factory pattern
	protected String whichEnemy;
	
	//Declare grid size.
	protected int gridSize;

	// ---------------------------------------
	// ---------------------------------------

	public Creature(Game game, int x, int y, int width, int height, int gridSize) {
		super(x, y, width, height); // Call entity class constructor

		alive = true;
		speed = DEFAULT_SPEED;
		xMove = tile.TILE_WIDTH;
		yMove = tile.TILE_HEIGHT;

		this.gridSize = gridSize;
		
		this.x = 0;
		this.y = 0;

		this.game = game;

	}

	// ---------------------------------------
	// ---------------------------------------

	// Move method generates a random direction to move in.
	public void move() {

		// Initialise new random variable
		rand = new Random();
		// 8 is the maximum and 1 is the minimum returned.
		randMove = rand.nextInt(8) + 1;

		// If random number is 1 move upwards.
		if (randMove == 1 && y != 0) {

			y -= yMove;
		}
		// If random number is 2 then move right
		else if (randMove == 2 && x != tile.TILE_WIDTH * (gridSize - 1)) {

			x += xMove;
		}
		// if random number is 3 then move down
		else if (randMove == 3 && y != tile.TILE_WIDTH * (gridSize - 1)) {

			y += yMove;
		}
		// if random number is 4 then move left
		else if (randMove == 4 && x != 0) {

			x -= xMove;
		}
		// if random number is 5 move up/left diagonally
		else if (randMove == 5 && x != 0) {
			if (y != 0) {
				x -= xMove;
				y -= yMove;
			}
		}
		// if random number is 6 move up/right diagonally
		else if (randMove == 6 && x != tile.TILE_WIDTH * (gridSize - 1)) {
			if (y != 0) {
				x += xMove;
				y -= yMove;
			}
		}
		// if random number is 7 move down/right diagonally
		else if (randMove == 7 && x != tile.TILE_WIDTH * (gridSize - 1)) {
			if (y != tile.TILE_HEIGHT * (gridSize - 1)) {
				x += xMove;
				y += yMove;
			}
		}
		// if random number is 8 move down/left diagonally
		else if (randMove == 8 && x != 0) {
			if (y != tile.TILE_HEIGHT * (gridSize - 1)) {
				x -= xMove;
				y += yMove;
			}
		}
		// Use recursion to call again if it cant move
		else {
			move();
		}

	}

	// Method which will randomly spawn enemies.
	// Part of factory pattern.
	public boolean spawnEnemy() {

		// Determines if enemy will spawn.
		boolean willSpawn = false;

		// Initialise new random variable
		rand = new Random();
		// 8 is the maximum and 1 is the minimum returned.
		randSpawn = rand.nextInt(3) + 1;

		// If creature isnt alive then give random chance to spawn.
		if (alive == false) {

			// If 1 then spawn a human.
			if (randSpawn == 1) {

				willSpawn = true;
			}
		}

		return willSpawn;
	}


	// ---------------------------------------
	// ---------------------------------------

	public int getxMove() {
		return xMove;
	}

	public void setxMove(int xMove) {
		this.xMove = xMove;
	}

	public int getyMove() {
		return yMove;
	}

	public void setyMove(int yMove) {
		this.yMove = yMove;
	}

	public boolean getAlive() {
		return alive;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	// Part of factory pattern
	public String getWhichEnemy() {

		return whichEnemy;
	}

	public void setWhichEnemy(String whichEnemy) {

		this.whichEnemy = whichEnemy;
	}

	public Game getGame() {

		return this.game;
	}
	
	public String getType() {
		
		return type;
	}
	
	public void setType(String type) {
		
		this.type = type;
	}

}