
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

//Main class of the game. Start, run etc...
public class Game implements Runnable {

	// Create private display object.
	private Display display;
	// Width, height and title variables.
	public int width, height;
	public String title;

	// Grid size variable
	private int gridSize;

	// Create new thread object.
	// Everything in this class runs separately to rest of app.
	private Thread thread;
	// Create running boolean for the game loop
	private boolean running = false;

	// A way to draw to the screen.
	// Buffer is a hidden screen but only holds data doesnt display
	private BufferStrategy bs;
	// Create graphics object.
	// Like a paint brush
	private Graphics g;

	// Declare a player object.
	Player player;

	// Declare random object.
	Random rand;
	// Declare world object
	private World world;

	// GUI**
	private SettingsGUI gui;

	// GAME LISTENERS**
	private List<GameListener> listeners = new ArrayList<GameListener>();

	// LIST OF ENEMIES**
	public CopyOnWriteArrayList<Creature> creaturesList = new CopyOnWriteArrayList<Creature>();

	// LIST OF ENEMIES**
	public CopyOnWriteArrayList<Creature> consumablesList = new CopyOnWriteArrayList<Creature>();

	// ----------------------------------------------
	// ----------------------------------------------

	// Create default Game constructor.
	public Game(String title, int width, int height, int gridSize) {

		running = false;

		this.gridSize = gridSize;

		this.width = width;
		this.height = height;
		this.title = title;

		player = new Player(this, 0, 0, gridSize);

		world = new World("", gridSize);

	}

	// --------------------------------------------
	// --------------------------------------------

	/* Add the given GameListener */
	public void addGameListener(GameListener listener) {
		listeners.add(listener);
		System.out.println("Game: Added a listener. ");
	}

	/* Remove the given GameListener */
	public void removeGameListener(GameListener listener) {
		listeners.remove(listener);
		System.out.println("Game: Removed a listener");
	}

	/* Construct a GameEvent and notify all its registered listeners */
	private void notifyListener() {
		GameEvent evt = new GameEvent(this);
		for (GameListener listener : listeners) {
			if (running) {
				listener.running(evt);
			}
		}
	}

	// Factory create enemy method.
	public static Creature createEnemy(Game game, String enemyName) {

		// Declare empty creature object
		Creature creature = null;

		// If human has been entered then create a human
		if (enemyName.equalsIgnoreCase("human")) {

			creature = new HumanEnemy(game, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT,
					game.gridSize);
		}
		// If deathclaw has been entered create a deathclaw.
		if (enemyName.equalsIgnoreCase("deathclaw")) {

			creature = new DeathClaw(game, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT,
					game.gridSize);
		}
		// If space bee has been entered create a space bee.
		if (enemyName.equalsIgnoreCase("spacebee")) {

			creature = new SpaceBee(game, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT,
					game.gridSize);
		}
		// By default creates a human
		if (creature == null) {

			creature = new HumanEnemy(game, 64, 64, game.gridSize);
		}

		return creature;
	}

	// This method randomly spawns enemies with a 1/3 chance per tick.
	// Takes in a list and if a creature object is returned it is added to the
	// list.
	// The objects in list are constantly updated.
	public void spawnEnemy() {

		// Declare randomSpawn int
		int randomSpawnEnemy;
		// Create new random object
		rand = new Random();
		// Declare empty creature object
		Creature creature = null;

		// Assigns random number between 1 and 9
		randomSpawnEnemy = rand.nextInt(9) + 1;

		// If the random spawn = 1.
		// Spawn a human enemy.
		if (randomSpawnEnemy == 1) {

			creature = createEnemy(this, "human");
			creaturesList.add(creature);
		}
		// If random = 2
		// Spawn a deathclaw Enemy
		if (randomSpawnEnemy == 2) {

			creature = createEnemy(this, "deathclaw");
			creaturesList.add(creature);
		}
		// If random = 3
		// Spawn a spacebee enemy
		if (randomSpawnEnemy == 3) {

			creature = createEnemy(this, "spacebee");
			creaturesList.add(creature);
		}
		// If random number != 1, 2 or 3
		// return out of function.
		else {
			return;
		}

	}

	// Factory create consumable method.
	public static Creature createConsumable(Game game, String consumableName) {

		// Declare empty creature object
		Creature creature = null;

		// If rat has been entered then create a rat
		if (consumableName.equalsIgnoreCase("rat")) {

			creature = new SpaceRat(game, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT,
					game.gridSize);
		}
		// If dog has been entered create a dog.
		if (consumableName.equalsIgnoreCase("dog")) {

			creature = new SpaceDog(game, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT,
					game.gridSize);
		}
		// By default creates a rat
		if (creature == null) {

			creature = new SpaceRat(game, 64, 64, game.gridSize);
		}

		return creature;
	}

	// This method randomly spawns consumable with a 1/3 chance per tick.
	// Takes in a list and if a creature object is returned it is added to the
	// list.
	// The objects in list are constantly updated.
	public void spawnConsumable() {

		// Declare randomSpawn int
		int randomSpawnConsum;
		// Create new random object
		rand = new Random();
		// Declare empty creature object
		Creature creature = null;

		// Assigns random number between 1 and 6
		randomSpawnConsum = rand.nextInt(6) + 1;

		// If the random spawn = 1.
		// Spawn a rat.
		if (randomSpawnConsum == 1) {

			creature = createConsumable(this, "rat");
			consumablesList.add(creature);
		}
		// If random = 2
		// Spawn a dog
		if (randomSpawnConsum == 2) {

			creature = createConsumable(this, "dog");
			consumablesList.add(creature);
		}
		// If random number != 1 or 2
		// return out of function.
		else {
			return;
		}

	}

	// An initialise method to initialise the graphics etc.
	private void init() {

		// Create new display object upon being called.
		display = new Display(title, width, height);
		// Initialise assets from assets class.
		Assets.init();

	}

	// Check collisions between all enemies.
	public void checkEnemyCollisions(Player p, Creature c) {

		// If the 2 creatures collide then remove the player
		if (p.getX() == c.getX() && p.getY() == c.getY()) {
			//If player does not have an enemy diet.
			if(p.isEnemyDiet() == false) {
				
				p.setAlive(false);
			}
			//If players diet
			else if(p.isEnemyDiet() == true) {
				
				c.setAlive(false); 
			}
		}
	}
	// Check collisions between all consumables.
	public void checkConsumCollisions(Player p, Creature c) {

		// If the 2 creatures collide then remove the player
		if (p.getX() == c.getX() && p.getY() == c.getY()) {
			
			//check to see which type of consumable was collided.
			if(p.isRatDiet() == true && c.getType() == "rat") {
				
				c.setAlive(false);
			}
			if(p.isDogDiet() == true && c.getType() == "dog") {
				
				c.setAlive(false); 
			}
		}
	}

	// Update method. Update variables.
	public void tick() {

		// Update enemies.
		for (Creature c : creaturesList) {
			// Do collision detection for each creature to player
			checkEnemyCollisions(player, c);
			// Update every creatures variables.
			c.tick();
		}
		//Update consumables.
		for(Creature c : consumablesList) {
			//Do collision detection for each consumable to player
			checkConsumCollisions(player, c);
			//Update each consumable
			c.tick();
		}

		world.tick();// Update world

		player.tick(); // Update player

		// Have a chance to spawn a random enemy.
		spawnEnemy();
		
		//Has a chance to spawn consumables
		spawnConsumable();

	}

	// render method. Draw to screen
	private void render() {

		// Sets buffer strategy object to the game canvas.
		bs = display.getCanvas().getBufferStrategy();
		// If canvas does not have buffer strategy.
		if (bs == null) {
			display.getCanvas().createBufferStrategy(3); // Use 3 buffers
			return;
		}
		// Create paint brush.
		g = bs.getDrawGraphics(); // Set graphics object to buffer graphics.

		// Clear screen for each render.
		g.clearRect(0, 0, width, height);

		// Draw here******************************************

		world.render(g); // Render world

		player.render(g); // Render player

		// Render enemies
		for (Creature c : creaturesList) {

			c.render(g);
		}
		//Render consumables.
		for(Creature c : consumablesList) {
			
			c.render(g); 
		}

		// End draw********************************************

		bs.show(); // Show graphics

		g.dispose(); // Graphics object disposed of
	}

	// This is the main run method.
	public void run() {
		// Only runs once.
		init();

		// initialise and set frames per second to 60.
		int fps = 60;
		// Theres 1,000,000,000 nano seconds in a second
		// 1 second divide by fps.
		double timePerTick = 1000000000 / fps;
		double delta = 0; // Amount of time we have to call tick and render.
		long now; // Current computer time
		long lastTime = System.nanoTime(); // Return current computer time. Nano
											// secs
		long timer = 0;
		int ticks = 0;

		// The game loop
		while (running) {
			// Set now to current time nano secs
			now = System.nanoTime();
			//
			delta += (now - lastTime) / timePerTick;
			timer += now - lastTime; // Adds to time since last block of code
										// was called.
			lastTime = now;

			// If delta is >= 1 tick and render.
			if (delta >= 1) {
				// tick();
				render();

				ticks++; // Increments ticks.
				delta--; // Subtract from delta.
			}

			// If timer is >= 1 second, print ticks and frames.
			if (timer >= 1000000000) {

				//System.out.println("Ticks/Frames: " + ticks);
				ticks = 0;
				timer = 0;
			}
		}

		stop(); // Stop running.
	}

	// Synchronised to work with threads
	public synchronized void start() {

		// The the game is already running then return out of method.
		if (running)
			return;

		// When started set running to true
		running = true;

		thread = new Thread(this); // Set new thread object to run game
									// class(this).
		// This calls the run method.
		thread.start();
	}

	// Stop thread safely
	public synchronized void stop() {

		// If game has stopped then return.
		if (!running)
			return;

		running = false;

		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// ---------------------------------------
	// ---------------------------------------

}