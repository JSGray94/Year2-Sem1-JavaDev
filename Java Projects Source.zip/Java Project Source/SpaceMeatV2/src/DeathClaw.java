import java.awt.Graphics;
import java.util.Random;

public class DeathClaw extends Creature {

	// Declare game object
	private Game game;
	// Declare gui object
	private SettingsGUI gui;
	// Declare tile object.
	Tile tile;

	// -----------------------------------
	// -----------------------------------

	// Human enemy constructor.
	public DeathClaw(Game game, int x, int y, int gridSize) {
		super(game, x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT, gridSize);

		this.game = game;

	}

	// ----------------------------------
	// ----------------------------------

	// Update variables
	@Override
	public void tick() {

		if (alive == true) {
			move();
		}
	}

	// Update images.
	@Override
	public void render(Graphics g) {

		if (alive == true) {
			// Draw player.
			g.drawImage(Assets.deathclaw, (int) x, (int) y, width, height, null);
		}
	}

	// ----------------------------------
	// ----------------------------------

}
