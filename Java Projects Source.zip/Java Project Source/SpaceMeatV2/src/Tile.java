
import java.awt.Graphics;
import java.awt.image.BufferedImage;

//represents in game tiles
public class Tile {

	//STATICS HERE
	
	//Holds 1 instance of every tile
	public static Tile[] tiles = new Tile[256];
	public static Tile greyTile = new GreyTile(0);	//Give grey tile an id of 0
	
	//CLASS
	
	//Tile attributes.
	//Width and height.
	public static final int TILE_WIDTH = 64, TILE_HEIGHT = 64;
	
	protected BufferedImage texture;	//Each tile has an image
	protected final int id;				//Each tile has an id
	
	//---------------------------------
	//---------------------------------
	
	public Tile(BufferedImage texture, int id) {
		
		this.texture = texture;
		this.id = id;
		
		//Index is id for tile.
		tiles[id] = this;
	}
	
	//--------------------------------
	//--------------------------------
	
	//If is solid then you cant walk on it.
	public boolean isSolid() {
		
		return false;
	}
	
	//Update variables
	public void tick() {
		
		
	}
	
	//Update graphics. Takes in x and y.
	public void render(Graphics g, int x, int y) {
		
		g.drawImage(texture, x, y, TILE_WIDTH, TILE_HEIGHT, null);
	}
	
	//------------------------------
	//------------------------------
	
	//Getter
	public int getId() {
		
		return id;
	}
}
