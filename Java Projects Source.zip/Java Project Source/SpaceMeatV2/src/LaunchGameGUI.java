import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class LaunchGameGUI extends JFrame implements GameListener {

	// Declare JPanel object
	private JPanel contentPane;

	// Declare grid size
	private int gridSize;

	// Declare setting gui
	static SettingsGUI gui;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LaunchGameGUI frame = new LaunchGameGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}

				System.out.println("Game Watcher GUI: Created.");

			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LaunchGameGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 227, 132);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		comboBox.addItem("3x3");
		comboBox.addItem("4x4");
		comboBox.addItem("5x5");
		comboBox.addItem("6x6");
		comboBox.addItem("7x7");
		comboBox.addItem("8x8");
		comboBox.addItem("9x9");
		comboBox.setBounds(10, 11, 185, 20);
		contentPane.add(comboBox);
		comboBox.setSelectedIndex(-1);

		comboBox.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent event) {
				//
				// Get the source of the component, which is our combo
				// box.
				//
				JComboBox comboBox = (JComboBox) event.getSource();

				Object selected = comboBox.getSelectedItem();
				if (selected.toString().equals("3x3")) {
					gridSize = 3;
				} else if (selected.toString().equals("4x4")) {
					gridSize = 4;
				}
				if (selected.toString().equals("5x5")) {
					gridSize = 5;
				} else if (selected.toString().equals("6x6")) {
					gridSize = 6;
				}
				if (selected.toString().equals("7x7")) {
					gridSize = 7;
				} else if (selected.toString().equals("8x8")) {
					gridSize = 8;
				}
				if (selected.toString().equals("9x9")) {
					gridSize = 9;
				}
			}
		});

		JButton btnStartGame = new JButton("Start Game");
		btnStartGame.setFont(new Font("Letter Gothic Std", Font.PLAIN, 12));
		btnStartGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// create new game object
				Game game = new Game("Space Meat", 576, 576, gridSize);
				// Start the game
				game.start();

				gui = new SettingsGUI(game);
				gui.run(game);

				// Observer pattern components
				GameWatcher gui = new GameWatcher(1); // Create GameWatcher
															// object

				game.addGameListener(gui); // Add gui to game listeners
			}
		});
		btnStartGame.setBounds(10, 52, 185, 23);
		contentPane.add(btnStartGame);
	}

	@Override
	public void running(GameEvent evt) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void notRunning(Game evt) {
		// TODO Auto-generated method stub
		
	}
}
